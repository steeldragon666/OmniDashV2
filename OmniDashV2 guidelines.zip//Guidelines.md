# OmniDash Brand Guidelines
*AI Enterprise Intelligence Platform*

---

## 🎯 Brand Foundation

### Brand Positioning
**OmniDash** is an AI-powered enterprise intelligence platform that transforms how businesses and government organizations make data-driven decisions. We democratize advanced AI capabilities, making sophisticated intelligence accessible to SMEs while meeting enterprise-grade requirements for government clients.

### Brand Values
- **Intelligence First**: Every feature backed by AI and data science
- **Accessible Innovation**: Complex technology made simple and usable
- **Trust & Security**: Enterprise-grade security and compliance
- **Sector Agnostic**: Equally powerful for SMEs and government
- **Continuous Evolution**: Always learning, always improving

### Brand Personality
- **Sophisticated** yet **approachable**
- **Innovative** yet **reliable**  
- **Comprehensive** yet **intuitive**
- **Professional** yet **human**

---

## 🎨 Visual Identity System

### Logo System

#### Primary Logo
```
[🔷] OmniDash
```
- Gradient cube icon + wordmark
- Minimum size: 120px width
- Clear space: 0.5x logo height on all sides

#### Logo Variations
1. **Primary**: Icon + Wordmark (horizontal)
2. **Stacked**: Icon above wordmark (vertical)
3. **Icon Only**: For tight spaces, social media
4. **Monochrome**: Single color versions
5. **Reverse**: White logo on dark backgrounds

#### Logo Construction
- **Icon**: 32x32px geometric cube with gradient
- **Wordmark**: Custom typography, gradient text treatment
- **Proportions**: Icon = 1x, Wordmark = 3.2x width
- **Spacing**: 0.5x icon width between icon and text

#### Logo Don'ts
- ❌ Don't stretch or distort proportions
- ❌ Don't change colors outside brand palette
- ❌ Don't place on busy backgrounds without backdrop
- ❌ Don't use gradients on print materials
- ❌ Don't recreate or modify the logo

---

## 🌈 Color System

### Primary Colors

#### Brand Gradient
```css
/* Primary Gradient */
background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
/* Blue to Purple - Core brand identity */
```

#### Core Colors
```css
/* Primary Blue */
--primary-600: #3B82F6;
--primary-500: #6366F1;
--primary-400: #818CF8;

/* Primary Purple */ 
--purple-600: #8B5CF6;
--purple-500: #A855F7;
--purple-400: #C084FC;
```

### Secondary Colors

#### Sector-Specific Colors
```css
/* SME Green */
--green-500: #10B981;
--green-100: #D1FAE5;

/* Government Blue */
--gov-blue-500: #3B82F6;
--gov-blue-100: #DBEAFE;

/* Enterprise Purple */
--enterprise-500: #8B5CF6;
--enterprise-100: #EDE9FE;
```

### UI System Colors

#### Neutrals
```css
/* Text Colors */
--foreground: #0F172A;      /* Primary text */
--muted-foreground: #64748B; /* Secondary text */

/* Backgrounds */
--background: #FFFFFF;       /* Main background */
--muted: #F1F5F9;           /* Secondary background */
--card: #FFFFFF;            /* Card backgrounds */
--border: #E2E8F0;          /* Border color */
```

#### Status Colors
```css
/* Success */
--success: #10B981;
--success-bg: #D1FAE5;

/* Warning */
--warning: #F59E0B;  
--warning-bg: #FEF3C7;

/* Error */
--error: #EF4444;
--error-bg: #FEE2E2;

/* Info */
--info: #3B82F6;
--info-bg: #DBEAFE;
```

### Color Usage Guidelines

#### Primary Usage
- **Brand Gradient**: Hero sections, CTA buttons, logo
- **Primary Blue**: Links, active states, primary actions
- **Primary Purple**: Accents, highlights, secondary actions

#### Accessibility Requirements
- **Text Contrast**: Minimum 4.5:1 ratio for body text
- **UI Contrast**: Minimum 3:1 ratio for UI elements
- **Color Blindness**: Never rely solely on color to convey information

---

## ✍️ Typography System

### Primary Typeface: Inter
**Usage**: UI, headings, body text, data displays
- **Weights**: 400 (Regular), 500 (Medium), 600 (SemiBold), 700 (Bold)
- **Why Inter**: Optimized for screens, excellent readability, professional yet modern

### Secondary Typeface: JetBrains Mono  
**Usage**: Code blocks, technical data, API documentation
- **Weights**: 400 (Regular), 500 (Medium)
- **Why JetBrains**: Developer-friendly, technical credibility

### Typography Scale

#### Headings
```css
/* Display - Hero Headlines */
font-size: 3.75rem; /* 60px */
font-weight: 700;
line-height: 1.1;

/* H1 - Page Titles */
font-size: 2.25rem; /* 36px */
font-weight: 700;
line-height: 1.2;

/* H2 - Section Headers */
font-size: 1.875rem; /* 30px */
font-weight: 600;
line-height: 1.3;

/* H3 - Subsection Headers */
font-size: 1.5rem; /* 24px */
font-weight: 600;
line-height: 1.4;

/* H4 - Card Titles */
font-size: 1.25rem; /* 20px */
font-weight: 600;
line-height: 1.4;

/* H5 - Component Labels */
font-size: 1.125rem; /* 18px */
font-weight: 500;
line-height: 1.4;
```

#### Body Text
```css
/* Large Body */
font-size: 1.125rem; /* 18px */
font-weight: 400;
line-height: 1.6;

/* Base Body */
font-size: 1rem; /* 16px */
font-weight: 400;
line-height: 1.6;

/* Small Body */
font-size: 0.875rem; /* 14px */
font-weight: 400;
line-height: 1.5;

/* Caption */
font-size: 0.75rem; /* 12px */
font-weight: 400;
line-height: 1.4;
```

### Typography Guidelines
- **Line Height**: 1.4-1.6 for optimal readability
- **Letter Spacing**: Default for most text, -0.025em for large headings
- **Paragraph Spacing**: 1rem between paragraphs
- **Max Line Length**: 75 characters for optimal reading

---

## 🎭 Iconography System

### Icon Style
- **Design**: Lucide React icon library (consistent, modern)
- **Style**: Outline icons with 2px stroke weight
- **Sizes**: 16px, 20px, 24px, 32px, 48px
- **Colors**: Inherit from parent or use neutral colors

### Icon Categories

#### Core Business Icons
- **Dashboard**: LayoutDashboard, BarChart3, PieChart
- **AI/Intelligence**: Bot, Brain, Zap, Rocket
- **Business**: ShoppingCart, DollarSign, Target, Award

#### Platform Icons  
- **Social**: Users, Heart, TrendingUp, Globe
- **Security**: Shield, Lock, AlertTriangle, CheckCircle2
- **Tools**: Settings, Search, Filter, Calendar

#### Sector Icons
- **Government**: Building, FileText, Award, Shield
- **SME**: MapPin, Store, Users, Growth

### Icon Usage Guidelines
- **Consistency**: Always use same icon for same concept
- **Context**: Icons should always have text labels or tooltips
- **Sizing**: Use consistent sizes within same interface area
- **Color**: Icons inherit color or use muted-foreground

---

## 📱 UI Component System

### Button System

#### Primary Button
```css
/* Primary CTA Button */
background: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
color: white;
padding: 12px 24px;
border-radius: 8px;
font-weight: 500;
font-size: 14px;
```

#### Secondary Button
```css
/* Secondary Action Button */
background: transparent;
border: 1px solid #E2E8F0;
color: #0F172A;
padding: 12px 24px;
border-radius: 8px;
font-weight: 500;
```

#### Button Sizes
- **Large**: 16px padding, 16px font-size
- **Default**: 12px padding, 14px font-size  
- **Small**: 8px padding, 12px font-size
- **Icon**: Square with icon, matching height

### Card System
```css
/* Standard Card */
background: white;
border: 1px solid #E2E8F0;
border-radius: 12px;
padding: 24px;
box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
```

### Form Elements
```css
/* Input Fields */
border: 1px solid #E2E8F0;
border-radius: 8px;
padding: 12px 16px;
font-size: 14px;
background: white;

/* Focus State */
border-color: #3B82F6;
box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
```

### Spacing System
- **Base unit**: 4px
- **Scale**: 4px, 8px, 12px, 16px, 20px, 24px, 32px, 48px, 64px, 96px
- **Component padding**: 12px, 16px, 24px
- **Section spacing**: 32px, 48px, 64px

---

## 📐 Layout System

### Grid System
- **Container**: Max-width 1200px, centered
- **Columns**: 12-column grid system
- **Gutters**: 24px between columns
- **Breakpoints**: 
  - Mobile: 320px-768px
  - Tablet: 768px-1024px  
  - Desktop: 1024px+

### Sidebar Navigation
- **Width**: 240px (collapsed: 64px)
- **Sections**: Grouped with headers
- **Active state**: Background highlight + icon color
- **Hover state**: Subtle background change

### Dashboard Layout
- **Header**: 64px height, sticky
- **Metrics**: 4-column grid on desktop, 2-column tablet, 1-column mobile
- **Cards**: 12px border-radius, 24px padding
- **Tables**: Zebra striping, 12px padding cells

---

## 🎙️ Brand Voice & Tone

### Voice Characteristics
- **Professional**: Authoritative without being intimidating  
- **Intelligent**: Shows expertise without being condescending
- **Accessible**: Complex concepts explained simply
- **Confident**: Assured in capabilities, honest about limitations
- **Helpful**: Solution-oriented, practical guidance

### Tone Variations

#### For SME Clients
- **Encouraging**: "Transform your business with AI intelligence"
- **Practical**: "Real insights, real results"
- **Supportive**: "We'll guide you every step of the way"

#### For Government Clients  
- **Authoritative**: "Enterprise-grade intelligence for public sector"
- **Compliant**: "Built for government security and compliance standards"
- **Impactful**: "Data-driven decisions for better public outcomes"

#### For Technical Content
- **Precise**: Clear, specific language
- **Educational**: Explain the "why" behind features
- **Transparent**: Honest about capabilities and limitations

### Writing Guidelines
- **Active voice** preferred over passive
- **Specific numbers** over vague quantities
- **Benefits first**, then features
- **Concise** but complete information
- **Consistent terminology** across all content

---

## 📋 Brand Applications

### Digital Applications

#### Website Headers
- **H1**: 36px Inter Bold + gradient text treatment
- **Subtitle**: 18px Inter Regular, muted color
- **CTA**: Primary gradient button with icon

#### Dashboard Elements
- **Metric Cards**: White background, subtle shadow, status colors for trends
- **Tables**: Clean lines, hover states, status badges
- **Forms**: Consistent spacing, clear labels, validation states

#### Marketing Materials
- **Hero Sections**: Brand gradient background, white text
- **Feature Cards**: Icon + title + description format
- **Testimonials**: Quote + attribution + company logo

### Print Applications (when needed)
- **Logo**: Single color version only
- **Colors**: Use solid colors, no gradients
- **Typography**: Inter Regular/Bold weights
- **Business Cards**: Minimal, logo + contact info

### Social Media
- **Profile Pictures**: Icon-only logo version
- **Cover Images**: Gradient background + wordmark
- **Post Graphics**: Brand colors, consistent icon style
- **Video Thumbnails**: Bold text, gradient accents

---

## ✅ Brand Checklist

### Before Any Design Work
- [ ] Does it align with brand values?
- [ ] Is it appropriate for target audience (SME/Government)?
- [ ] Does it maintain professional credibility?
- [ ] Is it accessible and inclusive?

### Visual Elements Checklist
- [ ] Logo used correctly (size, spacing, colors)
- [ ] Colors from established palette only
- [ ] Typography hierarchy followed
- [ ] Icons consistent in style and size
- [ ] Spacing system adhered to

### Content Checklist  
- [ ] Voice and tone appropriate for audience
- [ ] Technical accuracy verified
- [ ] Benefits clearly communicated
- [ ] Call-to-action clear and compelling
- [ ] Consistent terminology used

### Accessibility Checklist
- [ ] Color contrast ratios met (4.5:1 minimum)
- [ ] Text is readable at all sizes
- [ ] Icons have text labels/alternatives
- [ ] Interactive elements clearly defined
- [ ] Content works without color alone

---

## 📞 Brand Contact

**Brand Guardian**: [Omniscient]
**Last Updated**: [10/09/2025]
**Version**: 1.0

*For questions about brand implementation or to request brand assets, contact the design team.*

---

**© 2024 OmniDash. All brand guidelines are proprietary and confidential.**