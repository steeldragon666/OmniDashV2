
  # OmniDash- main

  This is a code bundle for OmniDash- main. The original project is available at https://www.figma.com/design/ZnKiS6CCs9mO9YkhuzrgH1/OmniDash--main.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  