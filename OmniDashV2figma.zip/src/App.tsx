import React, { useState } from "react";
import { OmniDashLogo } from "./components/omnidash-logo";
import { MetricCard } from "./components/metric-card";
import { AIAgentCard } from "./components/ai-agent-card";
import { ActivityFeed } from "./components/activity-feed";
import { OmniDashIconSystem } from "./components/omnidash-icons";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Badge } from "./components/ui/badge";
import { Card } from "./components/ui/card";
import { Avatar, AvatarFallback } from "./components/ui/avatar";
import { ScrollArea } from "./components/ui/scroll-area";
import { Separator } from "./components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./components/ui/dialog";
import {
  LayoutDashboard,
  Bot,
  ShoppingCart,
  LifeBuoy,
  Settings,
  Plus,
  Search,
  ChevronDown,
  Rocket,
  Play,
  Pause,
  Pencil,
  CheckCircle2,
  BarChart3,
  Calendar,
  ExternalLink,
  Cloud,
  Users,
  TrendingUp,
  AlertTriangle,
  Shield,
  Brain,
  Target,
  Globe,
  FileText,
  DollarSign,
  Eye,
  Zap,
  Heart,
  Star,
  Activity,
  PieChart,
  Lock,
  Award,
  Briefcase,
  Building,
  MapPin,
  Clock,
  Filter,
  Download,
  Upload,
  Bell,
  User,
  LogOut,
  MessageSquare,
  Crown,
  ChevronRight,
  Sparkles,
  LineChart,
  Gauge,
  Database,
  Monitor,
  Headphones,
  Coffee,
  Palette
} from "lucide-react";

// TYPES
interface Brand {
  id: string;
  name: string;
  email?: string;
  socials?: string[];
  sector?: "SME" | "Government" | "Enterprise";
  // Core Integrations
  xeroConnected?: boolean;
  gdriveConnected?: boolean;
  gcalConnected?: boolean;
  // Enhanced Integrations
  hubspotConnected?: boolean;
  predisConnected?: boolean;
  metaBusinessConnected?: boolean;
  tiktokBusinessConnected?: boolean;
  linkedinConnected?: boolean;
  brandwatchConnected?: boolean;
  clearbitConnected?: boolean;
  youtubeConnected?: boolean;
}

type AgentKey = 
  // Core Agents
  | "content" | "sales" | "crm" | "strategy" | "builder" | "competitor" | "events"
  // Intelligence Agents
  | "influencer" | "sentiment" | "revenue" | "compliance" 
  // Sector-Specific Agents
  | "public_sector" | "local_intelligence"
  // Design System
  | "icons";

interface WorkflowRow {
  id: string;
  name: string;
  agent: string;
  status: "Running" | "Completed" | "Queued" | "Failed";
  priority: "Low" | "Medium" | "High" | "Critical";
  lastRun?: string;
  nextRun?: string;
}

interface MetricCardData {
  title: string;
  value: string;
  icon: any;
  trend?: string;
  color?: "green" | "red" | "yellow" | "blue";
}

// Three-Tier System Types
type TierLevel = "marketing" | "intelligence" | "operations";

interface TierInfo {
  id: TierLevel;
  name: string;
  description: string;
  badge: string;
  badgeColor: string;
  available: boolean;
}

interface PreviewWidget {
  id: string;
  title: string;
  description: string;
  tier: TierLevel;
  locked: boolean;
  demoValue?: string;
  upgradeMessage?: string;
}

// MOCK DATA
const defaultBrands: Brand[] = [
  { 
    id: "brand-a", 
    name: "TechCorp SME", 
    email: "hello@techcorp.com", 
    socials: ["Instagram","YouTube","LinkedIn"], 
    sector: "SME",
    xeroConnected: true, 
    gdriveConnected: true, 
    hubspotConnected: true,
  },
  { 
    id: "brand-b", 
    name: "City Council", 
    email: "comms@city.gov", 
    socials: ["X/Twitter","Facebook"], 
    sector: "Government",
    gdriveConnected: true, 
    gcalConnected: true,
  },
];

const defaultWorkflows: WorkflowRow[] = [
  { id: "wf-1", name: "Q4 Content Campaign", agent: "Content Gen", status: "Running", priority: "High", lastRun: "2 hours ago", nextRun: "In 4 hours" },
  { id: "wf-2", name: "Influencer Outreach Wave 3", agent: "Influencer Intel", status: "Queued", priority: "Medium", nextRun: "Tomorrow 9AM" },
  { id: "wf-3", name: "Compliance Audit Sweep", agent: "Compliance Agent", status: "Completed", priority: "Critical", lastRun: "1 day ago" },
];

// Three-Tier System Configuration
const tierConfig: TierInfo[] = [
  {
    id: "marketing",
    name: "Marketing Hub",
    description: "Essential marketing automation and social media management",
    badge: "Pro",
    badgeColor: "bg-electric-lime text-brand-navy",
    available: true
  },
  {
    id: "intelligence", 
    name: "AI Intelligence",
    description: "Advanced AI insights and predictive analytics",
    badge: "Intelligence",
    badgeColor: "bg-gradient-omnidash text-white",
    available: false
  },
  {
    id: "operations",
    name: "Operations Suite", 
    description: "Enterprise-grade business intelligence and operations",
    badge: "Suite",
    badgeColor: "bg-hot-pink text-white",
    available: false
  }
];

const previewWidgets: PreviewWidget[] = [
  {
    id: "business-health",
    title: "Business Health Score",
    description: "AI-powered overall business performance rating",
    tier: "intelligence",
    locked: false,
    demoValue: "78%",
    upgradeMessage: "Unlock full business intelligence with detailed breakdown"
  },
  {
    id: "growth-opportunities", 
    title: "AI Growth Opportunities",
    description: "Machine learning detected business expansion opportunities",
    tier: "intelligence",
    locked: true,
    demoValue: "3 opportunities",
    upgradeMessage: "Upgrade to Intelligence tier to see detailed recommendations"
  },
  {
    id: "predictive-analytics",
    title: "Revenue Predictions",
    description: "AI forecasting for next quarter performance",
    tier: "intelligence", 
    locked: true,
    demoValue: "$127K projected",
    upgradeMessage: "Access predictive analytics with Intelligence upgrade"
  },
  {
    id: "operations-center",
    title: "Operations Intelligence",
    description: "Real-time business operations monitoring and optimization",
    tier: "operations",
    locked: true,
    demoValue: "5 alerts",
    upgradeMessage: "Unlock Operations Suite for complete business monitoring"
  }
];

// MAIN COMPONENT
export default function OmniDashScaffold() {
  const [brands, setBrands] = useState<Brand[]>(defaultBrands);
  const [activeBrand, setActiveBrand] = useState<string>(brands[0]?.id ?? "brand-a");
  const [activeAgent, setActiveAgent] = useState<AgentKey>("content");
  const [query, setQuery] = useState("");
  const [workflows] = useState<WorkflowRow[]>(defaultWorkflows);
  const [showAdvancedMetrics, setShowAdvancedMetrics] = useState(false);
  const [currentTier, setCurrentTier] = useState<TierLevel>("marketing");
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedUpgradeTier, setSelectedUpgradeTier] = useState<TierLevel>("intelligence");

  const brand = brands.find(b => b.id === activeBrand) || brands[0] || { 
    id: "default", 
    name: "Default Brand", 
    sector: "SME" as const,
    email: "",
    socials: []
  };

  const getMetricsForBrand = (brandData: Brand): MetricCardData[] => {
    // Base metrics for all brands
    const baseMetrics: MetricCardData[] = [
      { title: "Social Engagement", value: "Posts: 8 | Reach: 25K", icon: BarChart3, trend: "+12%", color: "green" },
      { title: "Sales Pipeline", value: "Open: 18 | Rev: $24K", icon: ShoppingCart, trend: "+8%", color: "green" },
      { title: "Support Quality", value: "Open: 2 | SLA: 98%", icon: LifeBuoy, trend: "-15%", color: "green" },
      { title: "Content Performance", value: "Queue: 5 | Score: 87", icon: Rocket, trend: "+22%", color: "green" },
    ];

    // Advanced metrics when toggled
    const advancedMetrics: MetricCardData[] = [
      { title: "Influencer ROI", value: "Active: 8 | ROI: 4.2x", icon: Users, trend: "+15%", color: "blue" },
      { title: "Viral Potential", value: "AI Score: 89/100", icon: TrendingUp, trend: "+31%", color: "green" },
      { title: "Crisis Alerts", value: "Risk: Low | Sentiment: +82%", icon: AlertTriangle, trend: "Stable", color: "green" },
      { title: "Compliance", value: "Score: 96% | Status: Clear", icon: Shield, trend: "+2%", color: "green" },
    ];

    // Government-specific metrics
    const govMetrics: MetricCardData[] = [
      { title: "Public Approval", value: "73% | Engagement: High", icon: Heart, trend: "+5%", color: "green" },
      { title: "Grant Success", value: "Rate: 67% | Active: 3", icon: Award, trend: "+12%", color: "blue" },
      { title: "Policy Impact", value: "Mentions: 45 | Positive: 82%", icon: FileText, trend: "+18%", color: "green" },
      { title: "Stakeholder Engagement", value: "Events: 2 | Rating: 4.2/5", icon: Building, trend: "+8%", color: "green" },
    ];

    if (brandData.sector === "Government" && showAdvancedMetrics) {
      return [...baseMetrics, ...govMetrics];
    }
    
    return showAdvancedMetrics ? [...baseMetrics, ...advancedMetrics] : baseMetrics;
  };

  const metrics = getMetricsForBrand(brand);

  function addBrand() {
    const id = `brand-${brands.length + 1}`;
    const name = `Brand ${String.fromCharCode(65 + brands.length)}`;
    setBrands(prev => [...prev, { 
      id, 
      name, 
      sector: "SME",
      email: "",
      socials: []
    }]);
    setActiveBrand(id);
  }

  return (
    <div className="h-screen w-full flex flex-col bg-background text-foreground">
      {/* HEADER */}
      <header className="sticky top-0 z-40 border-b bg-brand-navy/95 backdrop-blur">
        <div className="h-16 px-4 md:px-6 flex items-center gap-3">
          {/* Logo */}
          <OmniDashLogo variant="primary" size="md" />

          {/* Search */}
          <SearchBar query={query} setQuery={setQuery} />

          {/* Quick Actions */}
          <QuickActions 
            showAdvancedMetrics={showAdvancedMetrics}
            onToggleMetrics={() => setShowAdvancedMetrics(!showAdvancedMetrics)}
            onAddBrand={addBrand}
            currentTier={currentTier}
          />

          {/* User Menu */}
          <UserMenu />
        </div>
      </header>

      {/* BODY */}
      <div className="flex flex-1 overflow-hidden">
        {/* SIDEBAR */}
        <Sidebar 
          activeAgent={activeAgent} 
          setActiveAgent={setActiveAgent} 
          brandSector={brand.sector}
          currentTier={currentTier}
          onUpgradeClick={(tier) => {
            setSelectedUpgradeTier(tier);
            setShowUpgradeModal(true);
          }}
        />

        {/* MAIN CONTENT */}
        <main className="flex-1 overflow-y-auto bg-background">
          <div className="p-4 md:p-6 space-y-6">
            {/* Hero Banner */}
            <div className="bg-gradient-omnidash rounded-xl p-8 text-white glow-orange">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-4xl font-bold mb-2">AI Enterprise Intelligence</h1>
                  <p className="text-xl opacity-90">Transform your business with high-impact insights</p>
                  <div className="flex items-center gap-4 mt-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-electric-lime animate-pulse"></div>
                      <span className="text-sm font-medium">Live Intelligence Active</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Activity className="h-4 w-4" />
                      <span className="text-sm">12 Agents Running</span>
                    </div>
                  </div>
                </div>
                <div className="hidden lg:block">
                  <div className="text-right">
                    <p className="text-3xl font-bold">98.7%</p>
                    <p className="text-sm opacity-80">System Performance</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Business Health Score Preview */}
            {currentTier === "marketing" && (
              <BusinessHealthPreview 
                onUpgrade={() => {
                  setSelectedUpgradeTier("intelligence");
                  setShowUpgradeModal(true);
                }}
              />
            )}

            {/* Preview Widgets for Locked Features */}
            {currentTier === "marketing" && (
              <PreviewWidgetsSection
                widgets={previewWidgets}
                onUpgrade={(tier) => {
                  setSelectedUpgradeTier(tier);
                  setShowUpgradeModal(true);
                }}
              />
            )}

            {/* Brand Tabs */}
            <BrandTabs 
              brands={brands} 
              activeBrand={activeBrand} 
              setActiveBrand={setActiveBrand}
              onAddBrand={addBrand}
            />

            {/* Brand Configuration Panel */}
            <BrandConfigPanel 
              brand={brand} 
              onChange={(updated) => {
                setBrands((prev) => prev.map(x => x.id === brand.id ? { ...x, ...updated } : x));
              }} 
            />

            {/* Metrics Dashboard */}
            <MetricsDashboard 
              metrics={metrics} 
              currentTier={currentTier}
              onUpgrade={(tier) => {
                setSelectedUpgradeTier(tier);
                setShowUpgradeModal(true);
              }}
            />

            {/* Workflows Table */}
            <WorkflowsTable workflows={workflows} />

            {/* Agent-Specific Dashboard */}
            <AgentDashboard agent={activeAgent} brand={brand} />
          </div>
        </main>
      </div>

      {/* FOOTER */}
      <Footer />

      {/* UPGRADE MODAL */}
      <UpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        targetTier={selectedUpgradeTier}
        currentTier={currentTier}
        onUpgrade={(tier) => {
          setCurrentTier(tier);
          setShowUpgradeModal(false);
        }}
      />
    </div>
  );
}

// COMPONENT LIBRARY

function BusinessHealthPreview({ onUpgrade }: { onUpgrade: () => void }) {
  return (
    <Card className="relative overflow-hidden border-l-4 border-l-brand-orange">
      <div className="absolute top-0 right-0 bg-gradient-omnidash text-white px-3 py-1 text-xs font-semibold rounded-bl-lg">
        Preview Available
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-brand-orange/10">
              <Gauge className="h-6 w-6 text-brand-orange" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Business Health Score</h3>
              <p className="text-sm text-muted-foreground">AI-powered performance overview</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-brand-orange">78%</div>
            <div className="text-xs text-muted-foreground">Overall Health</div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center p-3 bg-electric-lime/10 rounded-lg">
            <div className="text-lg font-semibold text-electric-lime">85%</div>
            <div className="text-xs text-muted-foreground">Growth</div>
          </div>
          <div className="text-center p-3 bg-ice-blue/30 rounded-lg">
            <div className="text-lg font-semibold text-brand-navy">72%</div>
            <div className="text-xs text-muted-foreground">Efficiency</div>
          </div>
          <div className="text-center p-3 bg-electric-yellow/20 rounded-lg">
            <div className="text-lg font-semibold text-brand-navy">76%</div>
            <div className="text-xs text-muted-foreground">Risk</div>
          </div>
        </div>

        <Button 
          onClick={onUpgrade}
          className="w-full bg-gradient-omnidash text-white hover:opacity-90 hover-glow-orange"
        >
          <Brain className="h-4 w-4 mr-2" />
          Unlock Full Intelligence Analysis
        </Button>
      </div>
    </Card>
  );
}

function PreviewWidgetsSection({ 
  widgets, 
  onUpgrade 
}: { 
  widgets: PreviewWidget[]; 
  onUpgrade: (tier: TierLevel) => void; 
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {widgets.map((widget) => (
        <PreviewWidgetCard
          key={widget.id}
          widget={widget}
          onUpgrade={() => onUpgrade(widget.tier)}
        />
      ))}
    </div>
  );
}

function PreviewWidgetCard({ 
  widget, 
  onUpgrade 
}: { 
  widget: PreviewWidget; 
  onUpgrade: () => void; 
}) {
  const getTierColor = (tier: TierLevel) => {
    switch (tier) {
      case "intelligence": return "bg-gradient-omnidash";
      case "operations": return "bg-hot-pink";
      default: return "bg-electric-lime";
    }
  };

  const getTierIcon = (tier: TierLevel) => {
    switch (tier) {
      case "intelligence": return Brain;
      case "operations": return Monitor;
      default: return BarChart3;
    }
  };

  const TierIcon = getTierIcon(widget.tier);

  return (
    <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-omnidash-md hover-glow-orange ${widget.locked ? 'opacity-75' : ''}`}>
      {widget.locked && (
        <div className="absolute inset-0 bg-brand-navy/90 backdrop-blur-sm z-10 flex items-center justify-center">
          <div className="text-center text-white p-4">
            <Lock className="h-8 w-8 mx-auto mb-2 text-brand-orange" />
            <p className="text-sm font-medium mb-2">Feature Locked</p>
            <Button 
              size="sm" 
              onClick={onUpgrade}
              className="bg-gradient-omnidash text-white hover:opacity-90"
            >
              Upgrade to Unlock
            </Button>
          </div>
        </div>
      )}
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${getTierColor(widget.tier)} text-white`}>
              <TierIcon className="h-4 w-4" />
            </div>
            <h4 className="font-medium text-sm">{widget.title}</h4>
          </div>
          {!widget.locked && (
            <Badge className="bg-electric-lime text-brand-navy text-xs font-semibold">
              Preview
            </Badge>
          )}
        </div>
        
        <p className="text-xs text-muted-foreground mb-3">{widget.description}</p>
        
        {widget.demoValue && (
          <div className="mb-3">
            <div className="text-xl font-bold text-brand-orange">{widget.demoValue}</div>
          </div>
        )}
        
        {!widget.locked && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onUpgrade}
            className="w-full hover:border-brand-orange hover:text-brand-orange"
          >
            <Sparkles className="h-3 w-3 mr-1" />
            Unlock Full Features
          </Button>
        )}
      </div>
    </Card>
  );
}

function UpgradeModal({ 
  isOpen, 
  onClose, 
  targetTier, 
  currentTier, 
  onUpgrade 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  targetTier: TierLevel; 
  currentTier: TierLevel; 
  onUpgrade: (tier: TierLevel) => void; 
}) {
  const tierInfo = tierConfig.find(t => t.id === targetTier);
  
  if (!tierInfo) return null;

  const features = {
    intelligence: [
      "AI Business Health Score with detailed breakdown",
      "Predictive analytics and revenue forecasting", 
      "Advanced competitor intelligence",
      "Social sentiment analysis and crisis detection",
      "Automated compliance monitoring",
      "Influencer performance optimization"
    ],
    operations: [
      "Complete financial intelligence suite",
      "Customer lifecycle analytics",
      "Operations center with real-time monitoring",
      "Advanced workflow automation",
      "Executive reporting and dashboards", 
      "Enterprise integrations and APIs"
    ]
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${tierInfo.badgeColor}`}>
              {targetTier === "intelligence" ? <Brain className="h-5 w-5" /> : <Crown className="h-5 w-5" />}
            </div>
            Upgrade to {tierInfo.name}
          </DialogTitle>
          <DialogDescription>
            {tierInfo.description}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-brand-navy/5 to-brand-orange/5 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">What you'll get:</h4>
            <ul className="space-y-2">
              {features[targetTier]?.map((feature, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-electric-lime flex-shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-brand-navy/5 rounded-lg">
            <div>
              <div className="font-semibold">
                {targetTier === "intelligence" ? "Intelligence Tier" : "Operations Suite"}
              </div>
              <div className="text-sm text-muted-foreground">
                {targetTier === "intelligence" ? "Perfect for growing businesses" : "Enterprise-grade platform"}
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-brand-orange">
                {targetTier === "intelligence" ? "$99" : "$299"}
              </div>
              <div className="text-xs text-muted-foreground">per month</div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Maybe Later
          </Button>
          <Button 
            onClick={() => onUpgrade(targetTier)}
            className="bg-gradient-omnidash text-white hover:opacity-90 hover-glow-orange"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Upgrade Now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function SearchBar({ query, setQuery }: { query: string; setQuery: (q: string) => void }) {
  return (
    <div className="ml-4 flex-1 max-w-2xl">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 opacity-70" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search workflows, influencers, content, compliance reports..."
          className="w-full pl-9 pr-12"
        />
        <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] bg-muted px-1.5 py-0.5 rounded border">
          ⌘K
        </kbd>
      </div>
    </div>
  );
}

function QuickActions({ 
  showAdvancedMetrics, 
  onToggleMetrics, 
  onAddBrand,
  currentTier 
}: { 
  showAdvancedMetrics: boolean; 
  onToggleMetrics: () => void; 
  onAddBrand: () => void;
  currentTier: TierLevel;
}) {
  const getTierBadgeColor = () => {
    switch (currentTier) {
      case "intelligence": return "bg-gradient-omnidash text-white";
      case "operations": return "bg-hot-pink text-white";
      default: return "bg-electric-lime text-brand-navy";
    }
  };

  const getTierLabel = () => {
    switch (currentTier) {
      case "intelligence": return "Intelligence";
      case "operations": return "Operations";
      default: return "Pro";
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Badge className={`${getTierBadgeColor()} font-semibold`}>
        {getTierLabel()}
      </Badge>
      <Button
        variant={showAdvancedMetrics ? "default" : "ghost"}
        size="icon"
        onClick={onToggleMetrics}
        title="Toggle Advanced Metrics"
      >
        <Activity className="h-4 w-4" />
      </Button>
      <Button variant="ghost" size="icon" title="Notifications">
        <Bell className="h-4 w-4" />
      </Button>
      <Button onClick={onAddBrand} className="bg-gradient-omnidash text-white hover:opacity-90 hover-glow-orange">
        <Plus className="h-4 w-4 mr-2" /> Add Brand
      </Button>
    </div>
  );
}

function UserMenu() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex items-center gap-2 pl-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-gradient-omnidash text-white text-sm font-semibold">
              AN
            </AvatarFallback>
          </Avatar>
          <div className="text-left hidden md:block">
            <p className="text-sm font-medium">Alex Newton</p>
            <p className="text-xs text-muted-foreground">alex@omnidash.com</p>
          </div>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <User className="mr-2 h-4 w-4" />
          <span>Profile</span>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Settings className="mr-2 h-4 w-4" />
          <span>Settings</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="text-destructive">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function Sidebar({ 
  activeAgent, 
  setActiveAgent, 
  brandSector,
  currentTier,
  onUpgradeClick
}: { 
  activeAgent: AgentKey; 
  setActiveAgent: (agent: AgentKey) => void;
  brandSector?: string;
  currentTier: TierLevel;
  onUpgradeClick: (tier: TierLevel) => void;
}) {
  // Marketing Hub - Available for all users
  const marketingAgents = [
    { key: "content" as AgentKey, label: "Content Generation", icon: Bot, available: true },
    { key: "sales" as AgentKey, label: "Sales Manager", icon: ShoppingCart, available: true },
    { key: "crm" as AgentKey, label: "CRM & Help Desk", icon: LifeBuoy, available: true },
    { key: "strategy" as AgentKey, label: "Business Strategy", icon: Rocket, available: true },
    { key: "builder" as AgentKey, label: "Website Builder", icon: Cloud, available: true },
    { key: "events" as AgentKey, label: "Event Scheduler", icon: Calendar, available: true },
    { key: "icons" as AgentKey, label: "Icon Design System", icon: Palette, available: true },
  ];

  // AI Intelligence - Locked/Preview for non-intelligence users
  const intelligenceAgents = [
    { key: "influencer" as AgentKey, label: "Influencer Intelligence", icon: Users, available: currentTier !== "marketing", preview: true },
    { key: "sentiment" as AgentKey, label: "Social Intelligence", icon: Brain, available: currentTier !== "marketing", preview: true },
    { key: "revenue" as AgentKey, label: "Revenue Intelligence", icon: DollarSign, available: currentTier !== "marketing", preview: true },
    { key: "competitor" as AgentKey, label: "Competitor Analysis", icon: Target, available: currentTier !== "marketing", preview: false },
    { key: "compliance" as AgentKey, label: "Compliance & Security", icon: Shield, available: currentTier !== "marketing", preview: true },
  ];

  // Operations Suite - Locked for non-operations users  
  const operationsAgents = [
    { key: "public_sector" as AgentKey, label: "Financial Intelligence", icon: DollarSign, available: currentTier === "operations", preview: false },
    { key: "local_intelligence" as AgentKey, label: "Customer Intelligence", icon: Users, available: currentTier === "operations", preview: false },
    { key: "operations_center" as AgentKey, label: "Operations Center", icon: Monitor, available: currentTier === "operations", preview: false },
  ];

  return (
    <aside className="w-[280px] min-w-[260px] border-r bg-brand-navy p-3 hidden md:block">
      <ScrollArea className="h-full">
        <nav className="space-y-6">
          {/* Marketing Hub */}
          <div>
            <div className="flex items-center justify-between mb-3 px-2">
              <div className="text-xs uppercase font-semibold text-white/70">Marketing Hub</div>
              <Badge className="bg-electric-lime text-brand-navy text-xs font-semibold px-2 py-0.5">Pro</Badge>
            </div>
            <div className="space-y-1">
              {marketingAgents.map((agent) => (
                <SidebarItem
                  key={agent.key}
                  label={agent.label}
                  icon={agent.icon}
                  active={activeAgent === agent.key}
                  available={agent.available}
                  onClick={() => setActiveAgent(agent.key)}
                />
              ))}
            </div>
          </div>

          <Separator className="bg-white/10" />

          {/* AI Intelligence */}
          <div>
            <div className="flex items-center justify-between mb-3 px-2">
              <div className="text-xs uppercase font-semibold text-white/70">AI Intelligence</div>
              <div className="flex items-center gap-2">
                {currentTier === "marketing" && <Lock className="h-3 w-3 text-brand-orange" />}
                <Badge className="bg-gradient-omnidash text-white text-xs font-semibold px-2 py-0.5">
                  {currentTier === "marketing" ? "Locked" : "Intelligence"}
                </Badge>
              </div>
            </div>
            <div className="space-y-1">
              {intelligenceAgents.map((agent) => (
                <SidebarItem
                  key={agent.key}
                  label={agent.label}
                  icon={agent.icon}
                  active={activeAgent === agent.key}
                  available={agent.available}
                  locked={!agent.available}
                  preview={agent.preview && currentTier === "marketing"}
                  onClick={() => {
                    if (agent.available) {
                      setActiveAgent(agent.key);
                    } else {
                      onUpgradeClick("intelligence");
                    }
                  }}
                />
              ))}
              {currentTier === "marketing" && (
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-brand-orange hover:text-white hover:bg-brand-orange/20 mt-2"
                  onClick={() => onUpgradeClick("intelligence")}
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  <span className="text-sm">Unlock AI Intelligence</span>
                </Button>
              )}
            </div>
          </div>

          <Separator className="bg-white/10" />

          {/* Operations Suite */}
          <div>
            <div className="flex items-center justify-between mb-3 px-2">
              <div className="text-xs uppercase font-semibold text-white/70">Operations Suite</div>
              <div className="flex items-center gap-2">
                {currentTier !== "operations" && <Lock className="h-3 w-3 text-hot-pink" />}
                <Badge className="bg-hot-pink text-white text-xs font-semibold px-2 py-0.5">
                  {currentTier === "operations" ? "Suite" : "Locked"}
                </Badge>
              </div>
            </div>
            <div className="space-y-1">
              {operationsAgents.map((agent) => (
                <SidebarItem
                  key={agent.key}
                  label={agent.label}
                  icon={agent.icon}
                  active={activeAgent === agent.key}
                  available={agent.available}
                  locked={!agent.available}
                  onClick={() => {
                    if (agent.available) {
                      setActiveAgent(agent.key);
                    } else {
                      onUpgradeClick("operations");
                    }
                  }}
                />
              ))}
              {currentTier !== "operations" && (
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-hot-pink hover:text-white hover:bg-hot-pink/20 mt-2"
                  onClick={() => onUpgradeClick("operations")}
                >
                  <Crown className="mr-2 h-4 w-4" />
                  <span className="text-sm">Unlock Operations Suite</span>
                </Button>
              )}
            </div>
          </div>

          <Separator className="bg-white/10" />

          {/* Settings */}
          <div>
            <div className="text-xs uppercase font-semibold text-white/70 mb-3 px-2">Settings</div>
            <Button variant="ghost" className="w-full justify-start text-white/90 hover:text-white hover:bg-white/10">
              <Settings className="mr-2 h-4 w-4" /> Global Settings
            </Button>
          </div>
        </nav>
      </ScrollArea>
    </aside>
  );
}

function SidebarItem({ 
  label, 
  icon: Icon, 
  active, 
  available = true, 
  locked = false, 
  preview = false, 
  onClick 
}: { 
  label: string; 
  icon: any; 
  active?: boolean; 
  available?: boolean;
  locked?: boolean;
  preview?: boolean;
  onClick?: () => void 
}) {
  const getItemStyles = () => {
    if (active) {
      return "bg-brand-orange text-white hover:bg-brand-orange/90 glow-orange";
    }
    if (locked) {
      return "text-white/40 hover:text-white/60 hover:bg-white/5 cursor-pointer";
    }
    if (preview) {
      return "text-white/60 hover:text-white hover:bg-brand-orange/10 border border-brand-orange/30";
    }
    return "text-white/70 hover:text-white hover:bg-white/10";
  };

  return (
    <Button 
      variant="ghost"
      onClick={onClick}
      className={`w-full justify-between gap-2 ${getItemStyles()}`}
    >
      <div className="flex items-center gap-3">
        <Icon className="h-4 w-4 flex-shrink-0" />
        <span className="truncate text-sm">{label}</span>
      </div>
      <div className="flex items-center gap-1">
        {preview && (
          <Badge variant="outline" className="text-xs bg-brand-orange/20 text-brand-orange border-brand-orange/40">
            Preview
          </Badge>
        )}
        {locked && <Lock className="h-3 w-3" />}
        {!available && !locked && !preview && (
          <ChevronRight className="h-3 w-3" />
        )}
      </div>
    </Button>
  );
}

function BrandTabs({ 
  brands, 
  activeBrand, 
  setActiveBrand, 
  onAddBrand 
}: {
  brands: Brand[];
  activeBrand: string;
  setActiveBrand: (id: string) => void;
  onAddBrand: () => void;
}) {
  const getSectorColor = (sector?: string) => {
    switch (sector) {
      case 'Government': return 'bg-ice-blue';
      case 'Enterprise': return 'bg-hot-pink';
      default: return 'bg-electric-lime';
    }
  };

  return (
    <div className="flex items-center gap-2 border-b">
      {brands.map((b) => (
        <Button
          key={b.id}
          variant="ghost"
          onClick={() => setActiveBrand(b.id)}
          className={`px-4 py-2 border-b-2 rounded-none ${
            activeBrand === b.id
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${getSectorColor(b.sector)}`} />
            {b.name}
          </div>
        </Button>
      ))}
      <Button variant="ghost" onClick={onAddBrand} size="icon">
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );
}

function BrandConfigPanel({ brand, onChange }: { 
  brand: Brand; 
  onChange: (b: Partial<Brand>) => void 
}) {
  const integrations = [
    { name: "HubSpot", key: "hubspotConnected", icon: ShoppingCart, category: "CRM" },
    { name: "Predis.ai", key: "predisConnected", icon: Bot, category: "Content" },
    { name: "Meta Business", key: "metaBusinessConnected", icon: Globe, category: "Social" },
    { name: "TikTok Business", key: "tiktokBusinessConnected", icon: Zap, category: "Social" },
    { name: "LinkedIn API", key: "linkedinConnected", icon: Briefcase, category: "Social" },
    { name: "Brandwatch", key: "brandwatchConnected", icon: Eye, category: "Analytics" },
    { name: "Clearbit", key: "clearbitConnected", icon: Brain, category: "Intelligence" },
  ];

  const connectedCount = integrations.filter(i => brand[i.key as keyof Brand]).length;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold text-lg">Brand Configuration — {brand.name}</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Sector: {brand.sector} • Integrations: {connectedCount}/{integrations.length} connected
          </p>
        </div>
        <Button className="bg-gradient-omnidash text-white hover:opacity-90 hover-glow-orange">
          <CheckCircle2 className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Basic Info */}
        <div className="space-y-4">
          <h4 className="font-medium">Basic Information</h4>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium block mb-1">Email</label>
              <Input
                type="email"
                placeholder="name@brand.com"
                value={brand.email || ""}
                onChange={(e) => onChange({ email: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1">Sector</label>
              <select
                value={brand.sector || "SME"}
                onChange={(e) => onChange({ sector: e.target.value as any })}
                className="w-full h-9 px-3 border border-input bg-background rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="SME">Small/Medium Enterprise</option>
                <option value="Government">Government</option>
                <option value="Enterprise">Large Enterprise</option>
              </select>
            </div>
          </div>
        </div>

        {/* Social Platforms */}
        <div className="space-y-4">
          <h4 className="font-medium">Social Platforms</h4>
          <div className="space-y-2">
            {["Instagram", "TikTok", "YouTube", "X/Twitter", "LinkedIn", "Facebook"].map((platform) => (
              <label key={platform} className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={brand.socials?.includes(platform)}
                  onChange={(e) => {
                    const current = brand.socials || [];
                    const updated = e.target.checked
                      ? [...current, platform]
                      : current.filter(p => p !== platform);
                    onChange({ socials: updated });
                  }}
                  className="rounded border-gray-300"
                />
                {platform}
              </label>
            ))}
          </div>
        </div>

        {/* API Integrations */}
        <div className="space-y-4">
          <h4 className="font-medium">API Integrations</h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {integrations.map((integration) => (
              <IntegrationItem
                key={integration.name}
                integration={integration}
                connected={Boolean(brand[integration.key as keyof Brand])}
                onToggle={() => onChange({ [integration.key]: !brand[integration.key as keyof Brand] })}
              />
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function IntegrationItem({ 
  integration, 
  connected, 
  onToggle 
}: { 
  integration: any; 
  connected: boolean; 
  onToggle: () => void; 
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <div className="flex items-center gap-2">
        <integration.icon className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm">{integration.name}</span>
        <Badge variant="outline" className="text-xs">{integration.category}</Badge>
      </div>
      <Button
        variant={connected ? "default" : "outline"}
        size="sm"
        onClick={onToggle}
        className={connected ? "bg-success text-white hover:bg-success/90 border-success" : ""}
      >
        {connected ? "✓" : "Connect"}
      </Button>
    </div>
  );
}

function MetricsDashboard({ 
  metrics, 
  currentTier, 
  onUpgrade 
}: { 
  metrics: MetricCardData[]; 
  currentTier: TierLevel;
  onUpgrade: (tier: TierLevel) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Performance Metrics</h2>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="w-2 h-2 rounded-full bg-electric-lime animate-pulse"></div>
          <span>Real-time Intelligence</span>
          {currentTier === "marketing" && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onUpgrade("intelligence")}
              className="ml-4 hover:border-brand-orange hover:text-brand-orange"
            >
              <Sparkles className="h-3 w-3 mr-1" />
              Unlock AI Insights
            </Button>
          )}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {metrics.map((metric, i) => (
          <MetricCardComponent key={i} {...metric} />
        ))}
        
        {/* Add AI Insights Preview Cards for Marketing Tier */}
        {currentTier === "marketing" && (
          <>
            <Card className="p-4 border-dashed border-2 border-brand-orange/30 bg-gradient-to-br from-brand-orange/5 to-transparent hover:shadow-omnidash-md transition-all duration-300">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-brand-orange/10">
                    <Brain className="h-4 w-4 text-brand-orange" />
                  </div>
                  <h3 className="font-medium text-sm">AI Recommendations</h3>
                </div>
                <Lock className="h-4 w-4 text-brand-orange" />
              </div>
              <p className="text-sm text-muted-foreground mb-3">Get AI-powered suggestions to optimize performance</p>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onUpgrade("intelligence")}
                className="w-full hover:border-brand-orange hover:text-brand-orange"
              >
                Unlock Intelligence
              </Button>
            </Card>
            
            <Card className="p-4 border-dashed border-2 border-brand-orange/30 bg-gradient-to-br from-brand-orange/5 to-transparent hover:shadow-omnidash-md transition-all duration-300">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-brand-orange/10">
                    <LineChart className="h-4 w-4 text-brand-orange" />
                  </div>
                  <h3 className="font-medium text-sm">Predictive Analytics</h3>
                </div>
                <Lock className="h-4 w-4 text-brand-orange" />
              </div>
              <p className="text-sm text-muted-foreground mb-3">Forecast future performance with AI models</p>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => onUpgrade("intelligence")}
                className="w-full hover:border-brand-orange hover:text-brand-orange"
              >
                Unlock Forecasting
              </Button>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

function MetricCardComponent({ title, value, icon: Icon, trend, color = "green" }: MetricCardData) {
  const colorClasses = {
    green: "text-brand-navy bg-electric-lime",
    red: "text-white bg-hot-pink", 
    yellow: "text-brand-navy bg-electric-yellow",
    blue: "text-brand-navy bg-ice-blue"
  };

  return (
    <Card className="p-4 hover:shadow-omnidash-md transition-all duration-300 hover-glow-orange border-l-4 border-l-brand-orange">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-brand-orange/10">
            <Icon className="h-4 w-4 text-brand-orange" />
          </div>
          <h3 className="font-medium text-sm">{title}</h3>
        </div>
        {trend && (
          <Badge className={`text-xs ${colorClasses[color]} font-semibold`}>
            {trend}
          </Badge>
        )}
      </div>
      <p className="text-sm text-muted-foreground leading-relaxed">{value}</p>
    </Card>
  );
}

function WorkflowsTable({ workflows }: { workflows: WorkflowRow[] }) {
  return (
    <Card className="overflow-hidden">
      <div className="p-4 border-b bg-gradient-to-r from-brand-navy/5 to-brand-orange/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-lg">Active Workflows</h3>
            <Badge className="bg-electric-lime text-brand-navy font-semibold">
              {workflows.length} Running
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="hover:border-brand-orange hover:text-brand-orange">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
            <Button className="bg-gradient-omnidash text-white hover:opacity-90 hover-glow-orange">
              <Plus className="h-4 w-4 mr-2" /> New Workflow
            </Button>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b text-sm text-muted-foreground">
              <th className="text-left py-3 px-4">Workflow</th>
              <th className="text-left py-3 px-4">Agent</th>
              <th className="text-left py-3 px-4">Status</th>
              <th className="text-left py-3 px-4">Priority</th>
              <th className="text-left py-3 px-4">Schedule</th>
              <th className="text-right py-3 px-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {workflows.map((workflow) => (
              <WorkflowRowComponent key={workflow.id} workflow={workflow} />
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function WorkflowRowComponent({ workflow }: { workflow: WorkflowRow }) {
  const statusColors = {
    "Running": "bg-electric-lime text-brand-navy font-semibold",
    "Completed": "bg-ice-blue text-brand-navy font-semibold",
    "Failed": "bg-hot-pink text-white font-semibold",
    "Queued": "bg-electric-yellow text-brand-navy font-semibold"
  };

  const priorityColors = {
    "Critical": "bg-hot-pink text-white font-semibold",
    "High": "bg-brand-orange text-white font-semibold", 
    "Medium": "bg-ice-blue text-brand-navy font-semibold",
    "Low": "bg-warm-gray text-brand-navy font-medium"
  };

  return (
    <tr className="border-b hover:bg-brand-navy/5 transition-colors">
      <td className="py-3 px-4 font-semibold">{workflow.name}</td>
      <td className="py-3 px-4 text-sm text-muted-foreground">{workflow.agent}</td>
      <td className="py-3 px-4">
        <Badge className={`text-xs ${statusColors[workflow.status]}`}>
          {workflow.status}
        </Badge>
      </td>
      <td className="py-3 px-4">
        <Badge className={`text-xs ${priorityColors[workflow.priority]}`}>
          {workflow.priority}
        </Badge>
      </td>
      <td className="py-3 px-4 text-sm text-muted-foreground">
        {workflow.nextRun && <div>Next: {workflow.nextRun}</div>}
        {workflow.lastRun && <div className="text-xs">Last: {workflow.lastRun}</div>}
      </td>
      <td className="py-3 px-4">
        <div className="flex items-center justify-end gap-1">
          <Button variant="ghost" size="icon" title="Start" className="hover:bg-electric-lime/20 hover:text-electric-lime">
            <Play className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" title="Pause" className="hover:bg-electric-yellow/20 hover:text-electric-yellow">
            <Pause className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" title="Edit" className="hover:bg-brand-orange/20 hover:text-brand-orange">
            <Pencil className="h-4 w-4" />
          </Button>
        </div>
      </td>
    </tr>
  );
}

function AgentDashboard({ agent, brand }: { agent: AgentKey; brand: Brand }) {
  const agentConfig: Record<AgentKey, { title: string; desc: string; component: React.ReactNode }> = {
    // Core Agents
    content: { 
      title: "Content Generation & Social Publishing", 
      desc: `AI-powered content creation and scheduling for ${brand.name}`,
      component: <ContentAgent />
    },
    sales: { 
      title: "Sales Intelligence & Pipeline Management", 
      desc: `Revenue optimization and lead management for ${brand.name}`,
      component: <SalesAgentScaffold />
    },
    crm: { 
      title: "CRM & Customer Success Platform", 
      desc: `Support automation and customer lifecycle management`,
      component: <CRMAgentScaffold />
    },
    // Intelligence Agents
    influencer: { 
      title: "Influencer Intelligence Hub", 
      desc: `Discover, analyze, and manage influencer partnerships`,
      component: <InfluencerAgent />
    },
    sentiment: { 
      title: "Social Intelligence & Crisis Detection", 
      desc: `Advanced sentiment analysis and brand monitoring`,
      component: <SentimentAgentScaffold />
    },
    revenue: { 
      title: "Revenue Intelligence & Optimization", 
      desc: `AI-powered revenue forecasting and optimization`,
      component: <RevenueAgent />
    },
    // Specialized Agents
    strategy: { 
      title: "Business Strategy Generator", 
      desc: `Strategic planning with AI insights and market analysis`,
      component: <StrategyAgentScaffold />
    },
    builder: { 
      title: "Website Builder & Conversion Optimizer", 
      desc: `Automated landing pages and conversion optimization`,
      component: <BuilderAgentScaffold />
    },
    competitor: { 
      title: "Competitive Intelligence Platform", 
      desc: `Market research and competitor analysis`,
      component: <CompetitorAgentScaffold />
    },
    events: { 
      title: "Event Scheduler & Promotion Engine", 
      desc: `Event planning, promotion, and attendee management`,
      component: <EventsAgentScaffold />
    },
    compliance: { 
      title: "Compliance & Security Monitor", 
      desc: `Regulatory compliance and security auditing`,
      component: <ComplianceAgent />
    },
    // Sector-Specific Agents
    public_sector: { 
      title: "Public Sector Intelligence Tools", 
      desc: `Government-specific tools for policy analysis and public engagement`,
      component: <PublicSectorAgent />
    },
    local_intelligence: { 
      title: "Local Market Intelligence", 
      desc: `Hyperlocal insights and community engagement tools`,
      component: <LocalIntelligenceAgent />
    },
    // Design System
    icons: {
      title: "OmniDash Icon Design System",
      desc: "Comprehensive iconography system with three-tier architecture and intelligent geometric design",
      component: <OmniDashIconSystem />
    },
  };

  const config = agentConfig[agent];

  return (
    <Card>
      <div className="p-6 border-b">
        <h3 className="font-semibold text-lg">{config.title}</h3>
        <p className="text-muted-foreground mt-1">{config.desc}</p>
      </div>
      <div className="p-6">
        {config.component}
      </div>
    </Card>
  );
}

// Import agent components
import { ContentAgent } from "./components/agents/content-agent";
import { InfluencerAgent } from "./components/agents/influencer-agent";
import { RevenueAgent } from "./components/agents/revenue-agent";
import { ComplianceAgent } from "./components/agents/compliance-agent";
import { PublicSectorAgent } from "./components/agents/public-sector-agent";
import { LocalIntelligenceAgent } from "./components/agents/local-intelligence-agent";

// AGENT SCAFFOLDS - Temporary placeholder components for non-implemented agents

function SalesAgentScaffold() {
  return (
    <div className="space-y-4">
      <Card className="p-4 border-dashed border-2">
        <h4 className="font-medium mb-2">TODO: Sales Intelligence Integration</h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Connect to HubSpot/Salesforce CRM APIs</li>
          <li>• Implement lead scoring algorithms</li>
          <li>• Add pipeline forecasting with AI</li>
          <li>• Build automated follow-up sequences</li>
        </ul>
      </Card>
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-3 text-center">
          <h5 className="font-medium text-sm">Pipeline Value</h5>
          <p className="text-2xl font-bold mt-2">$124K</p>
        </Card>
        <Card className="p-3 text-center">
          <h5 className="font-medium text-sm">Conversion Rate</h5>
          <p className="text-2xl font-bold mt-2">23.5%</p>
        </Card>
        <Card className="p-3 text-center">
          <h5 className="font-medium text-sm">Avg Deal Size</h5>
          <p className="text-2xl font-bold mt-2">$6.9K</p>
        </Card>
      </div>
    </div>
  );
}

function CRMAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: Customer Success Platform</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Integrate customer support ticket systems</li>
        <li>• Add AI-powered response suggestions</li>
        <li>• Implement churn prediction models</li>
        <li>• Build customer health scoring</li>
      </ul>
    </Card>
  );
}

function SentimentAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: Social Intelligence & Crisis Detection</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Connect to Brandwatch/Mention APIs</li>
        <li>• Implement real-time sentiment analysis</li>
        <li>• Build crisis detection algorithms</li>
        <li>• Add viral content prediction models</li>
      </ul>
    </Card>
  );
}

function StrategyAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: AI Strategy Generator</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Integrate market research APIs</li>
        <li>• Build competitive analysis algorithms</li>
        <li>• Add strategic planning templates</li>
        <li>• Implement SWOT analysis automation</li>
      </ul>
    </Card>
  );
}

function BuilderAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: Website Builder & CRO Platform</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Build drag-and-drop page builder</li>
        <li>• Integrate with hosting providers</li>
        <li>• Add A/B testing framework</li>
        <li>• Implement conversion optimization tools</li>
      </ul>
    </Card>
  );
}

function CompetitorAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: Competitive Intelligence Platform</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Build web scraping infrastructure</li>
        <li>• Integrate market research data</li>
        <li>• Add competitor tracking algorithms</li>
        <li>• Implement market share analysis</li>
      </ul>
    </Card>
  );
}

function EventsAgentScaffold() {
  return (
    <Card className="p-4 border-dashed border-2">
      <h4 className="font-medium mb-2">TODO: Event Management Platform</h4>
      <ul className="text-sm text-muted-foreground space-y-1">
        <li>• Integrate with Google Calendar API</li>
        <li>• Build event registration system</li>
        <li>• Add social media promotion automation</li>
        <li>• Implement attendee engagement tracking</li>
      </ul>
    </Card>
  );
}

function Footer() {
  return (
    <footer className="border-t px-6 py-4 bg-brand-navy">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-8 text-white/70">
          <a href="#" className="hover:text-brand-orange transition-colors">Intelligence Status</a>
          <a href="#" className="hover:text-electric-lime transition-colors">Integrations</a>
          <a href="#" className="hover:text-hot-pink transition-colors">Support</a>
          <a href="#" className="hover:text-ice-blue transition-colors">Documentation</a>
        </div>
        <div className="flex items-center gap-6 text-white/70">
          <span>© {new Date().getFullYear()} OmniDash - AI Enterprise Intelligence</span>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-electric-lime animate-pulse glow-lime"></div>
            <span className="text-xs font-semibold text-electric-lime">All Systems Operational</span>
          </div>
        </div>
      </div>
    </footer>
  );
}