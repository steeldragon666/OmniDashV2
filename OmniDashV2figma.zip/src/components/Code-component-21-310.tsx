import React, { useState } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  Mail,
  Layers,
  FileText,
  Brain,
  Activity,
  Target,
  Eye,
  Lightbulb,
  Crosshair,
  DollarSign,
  Monitor,
  Cog,
  Package,
  UserCheck,
  BarChart3,
  Repeat,
  Trophy,
  Lock,
  Sparkles,
  ChevronRight,
  Copy,
  Download
} from "lucide-react";

// Icon data structure
interface IconDesign {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  tier: "marketing" | "intelligence" | "operations";
  category: string;
}

// Tier configurations
const tierConfigs = {
  marketing: {
    name: "Marketing Hub",
    badge: "Foundation",
    description: "Clean outlines with minimal fills",
    color: "bg-electric-lime text-brand-navy",
    style: "outline",
    complexity: "Simple, 1-2 visual elements"
  },
  intelligence: {
    name: "AI Intelligence", 
    badge: "Enhanced",
    description: "Gradient fills with geometric patterns",
    color: "bg-gradient-omnidash text-white",
    style: "gradient",
    complexity: "Medium, 2-3 visual elements with connecting lines"
  },
  operations: {
    name: "Operations Suite",
    badge: "Premium", 
    description: "Sophisticated multi-element compositions",
    color: "bg-hot-pink text-white",
    style: "premium",
    complexity: "Complex, 3-4 interconnected elements"
  }
};

// Icon definitions by tier
const iconLibrary: IconDesign[] = [
  // Tier 1: Marketing Hub Icons
  {
    id: "dashboard",
    name: "Dashboard",
    description: "Geometric grid with 3 ascending bars",
    icon: LayoutDashboard,
    tier: "marketing",
    category: "Analytics"
  },
  {
    id: "campaigns", 
    name: "Campaigns",
    description: "Arrow trajectory with target circles",
    icon: TrendingUp,
    tier: "marketing",
    category: "Marketing"
  },
  {
    id: "social-media",
    name: "Social Media", 
    description: "Connected nodes in hexagonal pattern",
    icon: Users,
    tier: "marketing",
    category: "Social"
  },
  {
    id: "email-marketing",
    name: "Email Marketing",
    description: "Envelope with geometric send arrow", 
    icon: Mail,
    tier: "marketing",
    category: "Marketing"
  },
  {
    id: "content-studio",
    name: "Content Studio",
    description: "Layered geometric shapes (creation concept)",
    icon: Layers,
    tier: "marketing", 
    category: "Content"
  },
  {
    id: "reports",
    name: "Reports",
    description: "Document stack with chart overlay",
    icon: FileText,
    tier: "marketing",
    category: "Analytics"
  },

  // Tier 2: AI Intelligence Icons  
  {
    id: "ai-command-center",
    name: "AI Command Center",
    description: "Neural network pattern in geometric form",
    icon: Brain,
    tier: "intelligence",
    category: "AI Core"
  },
  {
    id: "business-health-score", 
    name: "Business Health Score",
    description: "Circular progress with pulse pattern",
    icon: Activity,
    tier: "intelligence", 
    category: "AI Analytics"
  },
  {
    id: "predictive-analytics",
    name: "Predictive Analytics", 
    description: "Crystal/diamond shape with trend lines",
    icon: BarChart3,
    tier: "intelligence",
    category: "AI Analytics"
  },
  {
    id: "competitive-intelligence",
    name: "Competitive Intelligence",
    description: "Telescope/radar with scan lines", 
    icon: Eye,
    tier: "intelligence",
    category: "AI Intelligence"
  },
  {
    id: "ai-advisor",
    name: "AI Advisor",
    description: "Lightbulb with circuit pattern interior",
    icon: Lightbulb,
    tier: "intelligence", 
    category: "AI Core"
  },
  {
    id: "smart-targeting",
    name: "Smart Targeting",
    description: "Geometric target with AI nodes",
    icon: Crosshair,
    tier: "intelligence",
    category: "AI Marketing"
  },

  // Tier 3: Operations Suite Icons
  {
    id: "financial-intelligence",
    name: "Financial Intelligence", 
    description: "Currency symbol + graph + gear integration",
    icon: DollarSign,
    tier: "operations",
    category: "Financial"
  },
  {
    id: "customer-intelligence",
    name: "Customer Intelligence",
    description: "Person silhouettes + data flow lines",
    icon: Users,
    tier: "operations", 
    category: "Customer"
  },
  {
    id: "operations-center",
    name: "Operations Center",
    description: "Interconnected gears with flow arrows",
    icon: Monitor,
    tier: "operations",
    category: "Operations"
  },
  {
    id: "inventory-forecasting",
    name: "Inventory Forecasting", 
    description: "Stacked cubes with predictive arrow",
    icon: Package,
    tier: "operations",
    category: "Operations"
  },
  {
    id: "staff-optimization",
    name: "Staff Optimization",
    description: "Multiple person icons + efficiency curves",
    icon: UserCheck,
    tier: "operations", 
    category: "HR"
  },
  {
    id: "revenue-attribution",
    name: "Revenue Attribution",
    description: "Money flow with source tracking lines", 
    icon: BarChart3,
    tier: "operations",
    category: "Financial"
  },
  {
    id: "workflow-automation",
    name: "Workflow Automation",
    description: "Process flow with smart routing",
    icon: Repeat,
    tier: "operations",
    category: "Operations"
  },
  {
    id: "performance-benchmarking", 
    name: "Performance Benchmarking",
    description: "Trophy with comparison bars",
    icon: Trophy,
    tier: "operations",
    category: "Analytics"
  }
];

type IconState = "default" | "hover" | "active" | "disabled";

interface IconComponentProps {
  design: IconDesign;
  state: IconState;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
}

function IconComponent({ design, state, size = "md", showLabel = true }: IconComponentProps) {
  const sizeClasses = {
    sm: "h-4 w-4",
    md: "h-6 w-6", 
    lg: "h-8 w-8"
  };

  const containerSizeClasses = {
    sm: "p-2",
    md: "p-3",
    lg: "p-4"
  };

  const getIconStyles = () => {
    const baseClasses = `${sizeClasses[size]} transition-all duration-200`;
    
    switch (design.tier) {
      case "marketing":
        return getMarketingStyles(state, baseClasses);
      case "intelligence": 
        return getIntelligenceStyles(state, baseClasses);
      case "operations":
        return getOperationsStyles(state, baseClasses);
      default:
        return baseClasses;
    }
  };

  const getContainerStyles = () => {
    const baseClasses = `${containerSizeClasses[size]} rounded-lg transition-all duration-200`;
    
    if (state === "disabled") {
      return `${baseClasses} opacity-40 cursor-not-allowed bg-muted`;
    }
    
    switch (design.tier) {
      case "marketing":
        return `${baseClasses} bg-electric-lime/10 hover:bg-electric-lime/20`;
      case "intelligence":
        return `${baseClasses} bg-gradient-to-br from-brand-orange/10 to-brand-navy/10 hover:from-brand-orange/20 hover:to-brand-navy/20`;
      case "operations":
        return `${baseClasses} bg-hot-pink/10 hover:bg-hot-pink/20`;
      default:
        return baseClasses;
    }
  };

  const getMarketingStyles = (iconState: IconState, base: string) => {
    switch (iconState) {
      case "hover":
        return `${base} text-electric-lime scale-110`;
      case "active": 
        return `${base} text-electric-lime scale-95`;
      case "disabled":
        return `${base} text-warm-gray opacity-40`;
      default:
        return `${base} text-brand-navy`;
    }
  };

  const getIntelligenceStyles = (iconState: IconState, base: string) => {
    switch (iconState) {
      case "hover":
        return `${base} text-brand-orange scale-110 drop-shadow-lg`;
      case "active":
        return `${base} text-brand-orange scale-95`;
      case "disabled": 
        return `${base} text-warm-gray opacity-40`;
      default:
        return `${base} text-brand-orange`;
    }
  };

  const getOperationsStyles = (iconState: IconState, base: string) => {
    switch (iconState) {
      case "hover":
        return `${base} text-hot-pink scale-110 drop-shadow-lg`;
      case "active":
        return `${base} text-hot-pink scale-95`;
      case "disabled":
        return `${base} text-warm-gray opacity-40`;
      default:
        return `${base} text-hot-pink`;
    }
  };

  const IconElement = design.icon;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className={getContainerStyles()}>
        <IconElement className={getIconStyles()} />
        {state === "disabled" && (
          <Lock className="absolute -top-1 -right-1 h-3 w-3 text-warm-gray" />
        )}
      </div>
      {showLabel && (
        <div className="text-center">
          <p className="text-xs font-medium text-foreground">{design.name}</p>
          <p className="text-xs text-muted-foreground">{design.category}</p>
        </div>
      )}
    </div>
  );
}

export function OmniDashIconSystem() {
  const [selectedTier, setSelectedTier] = useState<"marketing" | "intelligence" | "operations">("marketing");
  const [selectedState, setSelectedState] = useState<IconState>("default");
  const [selectedSize, setSelectedSize] = useState<"sm" | "md" | "lg">("md");

  const filteredIcons = iconLibrary.filter(icon => icon.tier === selectedTier);
  const tierConfig = tierConfigs[selectedTier];

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-omnidash bg-clip-text text-transparent">
          OmniDash Icon Design System
        </h1>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          Intelligent Geometric iconography that combines precision with organic curves, 
          reflecting technological sophistication and human-centered design principles.
        </p>
      </div>

      {/* Design Principles */}
      <Card className="p-6 bg-gradient-to-r from-brand-navy/5 to-brand-orange/5">
        <h2 className="text-2xl font-semibold mb-4">Design Principles</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-2">
            <h3 className="font-semibold text-brand-orange">Geometric Foundation</h3>
            <p className="text-sm text-muted-foreground">Primary shapes with 2-4px radius corners</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold text-electric-lime">Human Touch</h3>
            <p className="text-sm text-muted-foreground">Subtle curves and organic elements</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold text-hot-pink">Visual Weight</h3>
            <p className="text-sm text-muted-foreground">Balanced positive/negative space</p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold text-ice-blue">Breathing Room</h3>
            <p className="text-sm text-muted-foreground">2px internal padding minimum</p>
          </div>
        </div>
      </Card>

      {/* Tier Selection */}
      <Tabs value={selectedTier} onValueChange={(value) => setSelectedTier(value as any)}>
        <TabsList className="grid grid-cols-3 w-full max-w-2xl mx-auto">
          <TabsTrigger value="marketing" className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-electric-lime"></div>
            Marketing Hub
          </TabsTrigger>
          <TabsTrigger value="intelligence" className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-brand-orange"></div>
            AI Intelligence
          </TabsTrigger>
          <TabsTrigger value="operations" className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-hot-pink"></div>
            Operations Suite
          </TabsTrigger>
        </TabsList>

        {/* Tier Details */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-semibold">{tierConfig.name}</h2>
              <Badge className={tierConfig.color}>
                {tierConfig.badge}
              </Badge>
            </div>
            <div className="text-right text-sm text-muted-foreground">
              <p>{tierConfig.description}</p>
              <p className="mt-1">{tierConfig.complexity}</p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center gap-4 mb-6 p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">State:</span>
              <div className="flex gap-1">
                {(["default", "hover", "active", "disabled"] as IconState[]).map((state) => (
                  <Button
                    key={state}
                    variant={selectedState === state ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedState(state)}
                    className="capitalize"
                  >
                    {state}
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Size:</span>
              <div className="flex gap-1">
                {(["sm", "md", "lg"] as const).map((size) => (
                  <Button
                    key={size}
                    variant={selectedSize === size ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSize(size)}
                    className="uppercase"
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Icon Grid */}
          <TabsContent value={selectedTier} className="mt-0">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {filteredIcons.map((icon) => (
                <div key={icon.id} className="relative">
                  <IconComponent
                    design={icon}
                    state={selectedState}
                    size={selectedSize}
                  />
                </div>
              ))}
            </div>
          </TabsContent>
        </Card>
      </Tabs>

      {/* Technical Specifications */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Cog className="h-5 w-5 text-brand-orange" />
            Technical Specifications
          </h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Canvas Size:</span>
              <span className="font-mono">24×24px</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Stroke Weight:</span>
              <span className="font-mono">2px</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Corner Radius:</span>
              <span className="font-mono">2-4px</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Color Mode:</span>
              <span className="font-mono">RGB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Export Formats:</span>
              <span className="font-mono">SVG, PNG @1x/@2x/@3x</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-electric-lime" />
            State Variations
          </h3>
          <div className="space-y-3 text-sm">
            <div>
              <span className="font-medium text-brand-orange">Default:</span>
              <span className="ml-2 text-muted-foreground">Full color, full opacity, standard stroke</span>
            </div>
            <div>
              <span className="font-medium text-electric-lime">Hover:</span>
              <span className="ml-2 text-muted-foreground">Scale 1.1x, brightness 110%, optional glow</span>
            </div>
            <div>
              <span className="font-medium text-hot-pink">Active:</span>
              <span className="ml-2 text-muted-foreground">Scale 0.95x, increased saturation, subtle shadow</span>
            </div>
            <div>
              <span className="font-medium text-warm-gray">Disabled:</span>
              <span className="ml-2 text-muted-foreground">40% opacity, grayscale, lock overlay</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Usage Guidelines */}
      <Card className="p-6">
        <h3 className="text-xl font-semibold mb-4">Usage Guidelines</h3>
        <div className="grid md:grid-cols-3 gap-6 text-sm">
          <div>
            <h4 className="font-semibold text-brand-orange mb-2">Icon Sizing Rules</h4>
            <ul className="space-y-1 text-muted-foreground">
              <li>• 16px, 20px, 24px, 32px variants</li>
              <li>• Maintain aspect ratio always</li>
              <li>• Snap to pixel grid for crisp edges</li>
              <li>• Use consistent sizing within interface areas</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-electric-lime mb-2">Spacing Guidelines</h4>
            <ul className="space-y-1 text-muted-foreground">
              <li>• Minimum 8px between icons</li>
              <li>• 2px internal padding minimum</li>
              <li>• 0.5x icon width from text labels</li>
              <li>• Consistent optical alignment</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-hot-pink mb-2">Do's and Don'ts</h4>
            <ul className="space-y-1 text-muted-foreground">
              <li>✓ Always provide text alternatives</li>
              <li>✓ Use consistent icons for same concepts</li>
              <li>✗ Don't mix icon styles within tiers</li>
              <li>✗ Don't modify stroke weight</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* Export Options */}
      <Card className="p-6 bg-gradient-to-r from-brand-navy/5 to-brand-orange/5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">Export Icon Library</h3>
            <p className="text-muted-foreground">Download complete icon set with all states and variants</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="hover:border-brand-orange hover:text-brand-orange">
              <Copy className="h-4 w-4 mr-2" />
              Copy SVG
            </Button>
            <Button className="bg-gradient-omnidash text-white hover:opacity-90">
              <Download className="h-4 w-4 mr-2" />
              Download Kit
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}