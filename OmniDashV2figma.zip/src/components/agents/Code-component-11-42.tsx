import React, { useState } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Target,
  Users,
  Calendar,
  Zap,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Brain,
  Lightbulb,
  Star,
  Eye,
  Filter,
  Download,
  Settings,
  RefreshCw
} from "lucide-react";

interface RevenueMetric {
  id: string;
  title: string;
  value: number;
  change: number;
  period: string;
  trend: "up" | "down" | "stable";
  format: "currency" | "percentage" | "number";
}

interface PredictiveInsight {
  id: string;
  type: "opportunity" | "risk" | "forecast";
  title: string;
  description: string;
  impact: "high" | "medium" | "low";
  confidence: number;
  timeframe: string;
  action?: string;
}

const mockMetrics: RevenueMetric[] = [
  {
    id: "1",
    title: "Monthly Recurring Revenue",
    value: 124750,
    change: 23.5,
    period: "vs last month",
    trend: "up",
    format: "currency"
  },
  {
    id: "2", 
    title: "Customer Lifetime Value",
    value: 8420,
    change: 15.2,
    period: "vs last quarter",
    trend: "up",
    format: "currency"
  },
  {
    id: "3",
    title: "Churn Rate",
    value: 2.3,
    change: -18.5,
    period: "vs last month",
    trend: "up",
    format: "percentage"
  },
  {
    id: "4",
    title: "Revenue per Customer",
    value: 450,
    change: 8.7,
    period: "vs last quarter",
    trend: "up",
    format: "currency"
  }
];

const mockInsights: PredictiveInsight[] = [
  {
    id: "1",
    type: "opportunity",
    title: "Enterprise Upsell Opportunity",
    description: "12 SME customers showing high engagement patterns similar to successful enterprise upgrades.",
    impact: "high",
    confidence: 87,
    timeframe: "Next 30 days",
    action: "Launch targeted enterprise feature campaign"
  },
  {
    id: "2",
    type: "risk",
    title: "Churn Risk Alert",
    description: "8 government sector clients have decreased usage by 40% in the last 14 days.",
    impact: "medium",
    confidence: 92,
    timeframe: "Next 14 days",
    action: "Initiate customer success outreach"
  },
  {
    id: "3",
    type: "forecast",
    title: "Q1 Revenue Projection",
    description: "Based on current trends, projected to exceed Q1 targets by 15% ($180K additional revenue).",
    impact: "high",
    confidence: 78,
    timeframe: "Q1 2025"
  }
];

export function RevenueAgent() {
  const [selectedTimeframe, setSelectedTimeframe] = useState("monthly");
  const [activeTab, setActiveTab] = useState("dashboard");

  const formatValue = (value: number, format: string) => {
    switch (format) {
      case "currency":
        return new Intl.NumberFormat("en-US", {
          style: "currency",
          currency: "USD",
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        }).format(value);
      case "percentage":
        return `${value.toFixed(1)}%`;
      default:
        return value.toLocaleString();
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "high": return "text-destructive";
      case "medium": return "text-warning";
      case "low": return "text-success";
      default: return "text-muted-foreground";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "opportunity": return <TrendingUp className="h-4 w-4 text-success" />;
      case "risk": return <AlertTriangle className="h-4 w-4 text-destructive" />;
      case "forecast": return <Brain className="h-4 w-4 text-info" />;
      default: return <Eye className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 text-white">
            <DollarSign className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Revenue Intelligence & Optimization</h2>
            <p className="text-muted-foreground">AI-powered revenue forecasting and optimization</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-success text-white">Processing</Badge>
          <Badge variant="outline">Last updated 5 min ago</Badge>
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="predictions" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Predictions
          </TabsTrigger>
          <TabsTrigger value="optimization" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Optimization
          </TabsTrigger>
          <TabsTrigger value="segmentation" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Segmentation
          </TabsTrigger>
          <TabsTrigger value="actions" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Actions
          </TabsTrigger>
        </TabsList>

        {/* Revenue Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Revenue Overview</h3>
            <div className="flex items-center gap-2">
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid md:grid-cols-4 gap-4">
            {mockMetrics.map((metric) => (
              <Card key={metric.id} className="p-6 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-cyan-500/10">
                    <DollarSign className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div className={`flex items-center gap-1 text-sm ${
                    metric.trend === "up" ? "text-success" : 
                    metric.trend === "down" ? "text-destructive" : 
                    "text-muted-foreground"
                  }`}>
                    {metric.trend === "up" ? <ArrowUpRight className="h-4 w-4" /> :
                     metric.trend === "down" ? <ArrowDownRight className="h-4 w-4" /> : null}
                    {metric.change > 0 ? "+" : ""}{metric.change.toFixed(1)}%
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-muted-foreground">{metric.title}</h4>
                  <div className="text-2xl font-bold mt-1">{formatValue(metric.value, metric.format)}</div>
                  <div className="text-xs text-muted-foreground mt-1">{metric.period}</div>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Revenue Chart */}
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Revenue Trends</h3>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">MRR</Button>
                  <Button variant="outline" size="sm">ARR</Button>
                  <Button variant="outline" size="sm">Growth</Button>
                </div>
              </div>
              <div className="h-80 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                  <p className="text-muted-foreground">Revenue trend visualization</p>
                  <p className="text-sm text-muted-foreground">Interactive charts showing MRR, growth rate, and forecasts</p>
                </div>
              </div>
            </Card>

            {/* Goal Tracking */}
            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Revenue Goals</h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm">Monthly Target</span>
                      <span className="text-sm font-medium">$150K</span>
                    </div>
                    <Progress value={83} className="h-2" />
                    <div className="text-xs text-muted-foreground mt-1">83% completed • $124.7K achieved</div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm">Quarterly Target</span>
                      <span className="text-sm font-medium">$450K</span>
                    </div>
                    <Progress value={67} className="h-2" />
                    <div className="text-xs text-muted-foreground mt-1">67% completed • $301.5K achieved</div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm">Annual Target</span>
                      <span className="text-sm font-medium">$1.8M</span>
                    </div>
                    <Progress value={56} className="h-2" />
                    <div className="text-xs text-muted-foreground mt-1">56% completed • $1.01M achieved</div>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Customer Metrics</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Customers</span>
                    <div className="text-right">
                      <div className="font-semibold">247</div>
                      <div className="text-xs text-success">+12</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">New This Month</span>
                    <div className="text-right">
                      <div className="font-semibold">18</div>
                      <div className="text-xs text-success">+3</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Churned</span>
                    <div className="text-right">
                      <div className="font-semibold">6</div>
                      <div className="text-xs text-destructive">+2</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Net Growth</span>
                    <div className="text-right">
                      <div className="font-semibold">+12</div>
                      <div className="text-xs text-success">5.1%</div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Predictive Analytics */}
        <TabsContent value="predictions" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">AI-Powered Insights</h3>
                <Badge className="bg-info text-white">Updated 2 hours ago</Badge>
              </div>

              <div className="space-y-4">
                {mockInsights.map((insight) => (
                  <Card key={insight.id} className="p-4 border-l-4 border-l-primary">
                    <div className="flex items-start gap-3">
                      <div className="mt-1">
                        {getTypeIcon(insight.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium">{insight.title}</h4>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={`text-xs ${getImpactColor(insight.impact)}`}>
                              {insight.impact} impact
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {insight.confidence}% confidence
                            </Badge>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {insight.timeframe}
                            </div>
                          </div>
                          {insight.action && (
                            <Button size="sm" variant="outline">
                              <Zap className="h-4 w-4 mr-2" />
                              Take Action
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Forecast Accuracy</h4>
                <div className="space-y-3">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-success">94.2%</div>
                    <div className="text-sm text-muted-foreground">Average accuracy</div>
                  </div>
                  <Progress value={94} className="h-2" />
                  <div className="text-xs text-muted-foreground">Based on last 90 days</div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Model Performance</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Churn Prediction</span>
                    <Badge className="bg-success text-white">92%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>LTV Forecasting</span>
                    <Badge className="bg-success text-white">89%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Revenue Projection</span>
                    <Badge className="bg-success text-white">96%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Upsell Likelihood</span>
                    <Badge className="bg-warning text-white">76%</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Next 30 Days</h4>
                <div className="space-y-3">
                  <div className="text-center">
                    <div className="text-lg font-bold">$142K</div>
                    <div className="text-sm text-muted-foreground">Projected Revenue</div>
                    <Badge className="mt-1 bg-success text-white">+13.8%</Badge>
                  </div>
                  <Separator />
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>New Customers</span>
                      <span className="font-medium">15-18</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Possible Churn</span>
                      <span className="font-medium">3-5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Upsell Opportunities</span>
                      <span className="font-medium">8-12</span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Optimization Engine */}
        <TabsContent value="optimization" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Pricing Optimization</h3>
              <div className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Lightbulb className="h-4 w-4 text-warning" />
                    <span className="font-medium">Recommendation</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Consider increasing Enterprise tier pricing by 12% based on feature utilization analysis.
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge className="bg-success text-white">+$24K potential MRR</Badge>
                    <Button size="sm" variant="outline">View Details</Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h5 className="font-medium">A/B Test Results</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 border rounded">
                      <span className="text-sm">Free Trial Extension (14→21 days)</span>
                      <Badge className="bg-success text-white">+23% conversion</Badge>
                    </div>
                    <div className="flex justify-between items-center p-2 border rounded">
                      <span className="text-sm">Annual Discount (20%→25%)</span>
                      <Badge className="bg-success text-white">+31% annual plans</Badge>
                    </div>
                    <div className="flex justify-between items-center p-2 border rounded">
                      <span className="text-sm">Feature Bundling</span>
                      <Badge className="bg-info text-white">Testing</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Conversion Funnel</h3>
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Website Visitors</span>
                    <span className="font-medium">12,847</span>
                  </div>
                  <Progress value={100} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Trial Signups</span>
                    <span className="font-medium">1,284 (10.0%)</span>
                  </div>
                  <Progress value={78} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Trials</span>
                    <span className="font-medium">896 (69.8%)</span>
                  </div>
                  <Progress value={54} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Paid Conversions</span>
                    <span className="font-medium">278 (31.0%)</span>
                  </div>
                  <Progress value={17} className="h-2" />
                </div>

                <Separator />

                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Optimization Opportunities</h5>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <ArrowUpRight className="h-3 w-3 text-success" />
                      <span>Improve trial activation: +15% potential</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ArrowUpRight className="h-3 w-3 text-success" />
                      <span>Optimize onboarding: +8% conversion</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ArrowUpRight className="h-3 w-3 text-success" />
                      <span>Better trial engagement: +12% retention</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Revenue Attribution Analysis</h3>
            <div className="h-64 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-lg">
              <div className="text-center">
                <PieChart className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                <p className="text-muted-foreground">Revenue attribution visualization</p>
                <p className="text-sm text-muted-foreground">Sankey diagram showing revenue sources and customer journey paths</p>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Customer Segmentation */}
        <TabsContent value="segmentation" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Customer Segments</h3>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Create Segment
                </Button>
              </div>

              <div className="space-y-4">
                <Card className="p-4 border-l-4 border-l-success">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">High-Value Enterprise</h4>
                    <Badge className="bg-success text-white">89 customers</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Enterprise customers with high engagement and expanding usage patterns.
                  </p>
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div>
                      <div className="font-semibold">$2,100</div>
                      <div className="text-muted-foreground">Avg MRR</div>
                    </div>
                    <div>
                      <div className="font-semibold">98.2%</div>
                      <div className="text-muted-foreground">Retention</div>
                    </div>
                    <div>
                      <div className="font-semibold">87%</div>
                      <div className="text-muted-foreground">Satisfaction</div>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-info">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">Growing SME</h4>
                    <Badge className="bg-info text-white">134 customers</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Small-medium businesses with consistent growth and feature adoption.
                  </p>
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div>
                      <div className="font-semibold">$485</div>
                      <div className="text-muted-foreground">Avg MRR</div>
                    </div>
                    <div>
                      <div className="font-semibold">92.1%</div>
                      <div className="text-muted-foreground">Retention</div>
                    </div>
                    <div>
                      <div className="font-semibold">82%</div>
                      <div className="text-muted-foreground">Satisfaction</div>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-warning">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">At-Risk Government</h4>
                    <Badge className="bg-warning text-white">24 customers</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Government clients with decreased usage requiring immediate attention.
                  </p>
                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div>
                      <div className="font-semibold">$750</div>
                      <div className="text-muted-foreground">Avg MRR</div>
                    </div>
                    <div>
                      <div className="font-semibold">78.3%</div>
                      <div className="text-muted-foreground">Retention</div>
                    </div>
                    <div>
                      <div className="font-semibold">65%</div>
                      <div className="text-muted-foreground">Satisfaction</div>
                    </div>
                  </div>
                </Card>
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Segment Performance</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Highest LTV</span>
                    <Badge variant="outline">Enterprise</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Fastest Growing</span>
                    <Badge variant="outline">SME</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Most Engaged</span>
                    <Badge variant="outline">Enterprise</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Needs Attention</span>
                    <Badge variant="outline">Government</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Behavior Patterns</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-warning" />
                    <span>Power users engage 5.2x more</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-success" />
                    <span>API usage predicts retention</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-info" />
                    <span>Team size correlates with LTV</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Daily users churn 60% less</span>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Personalization Engine</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Active Campaigns</span>
                    <span className="font-medium">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg Lift</span>
                    <span className="font-medium text-success">+23%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Segments Targeted</span>
                    <span className="font-medium">12/15</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Action Items */}
        <TabsContent value="actions" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Priority Recommendations</h3>
                <Badge className="bg-destructive text-white">3 Critical</Badge>
              </div>

              <div className="space-y-4">
                <Card className="p-4 border-l-4 border-l-destructive">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-destructive" />
                      <h4 className="font-medium">Critical Churn Risk</h4>
                    </div>
                    <Badge className="bg-destructive text-white">Critical</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    8 government sector accounts showing 40% usage decrease
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">Impact: -$18K MRR</div>
                    <Button size="sm" className="bg-destructive text-white">
                      Act Now
                    </Button>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-warning">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-warning" />
                      <h4 className="font-medium">Upsell Opportunity</h4>
                    </div>
                    <Badge className="bg-warning text-white">High</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    12 SME customers ready for enterprise features
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">Impact: +$24K MRR</div>
                    <Button size="sm" className="bg-warning text-white">
                      Contact
                    </Button>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-success">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      <h4 className="font-medium">Pricing Optimization</h4>
                    </div>
                    <Badge className="bg-success text-white">Medium</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Enterprise tier pricing increase recommended
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">Impact: +$32K MRR</div>
                    <Button size="sm" variant="outline">
                      Review
                    </Button>
                  </div>
                </Card>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Implementation Timeline</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-destructive"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Immediate (0-7 days)</h5>
                    <p className="text-xs text-muted-foreground">Churn prevention outreach</p>
                  </div>
                  <Badge variant="outline">8 accounts</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-warning"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Short-term (1-4 weeks)</h5>
                    <p className="text-xs text-muted-foreground">Enterprise upsell campaign</p>
                  </div>
                  <Badge variant="outline">12 prospects</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-info"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Medium-term (1-3 months)</h5>
                    <p className="text-xs text-muted-foreground">Pricing strategy implementation</p>
                  </div>
                  <Badge variant="outline">All tiers</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-success"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Long-term (3+ months)</h5>
                    <p className="text-xs text-muted-foreground">Product feature optimization</p>
                  </div>
                  <Badge variant="outline">Platform-wide</Badge>
                </div>
              </div>

              <Separator className="my-4" />

              <div>
                <h4 className="font-medium mb-3">Expected Impact</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Revenue Protection</span>
                    <span className="font-medium text-success">$18K/month</span>
                  </div>
                  <div className="flex justify-between">
                    <span>New Revenue</span>
                    <span className="font-medium text-success">$56K/month</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Impact</span>
                    <span className="font-bold text-success">$74K/month</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">ROI Projections</h3>
            <div className="h-64 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-lg">
              <div className="text-center">
                <Target className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                <p className="text-muted-foreground">ROI projection timeline</p>
                <p className="text-sm text-muted-foreground">Gantt chart showing implementation timeline and expected returns</p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}