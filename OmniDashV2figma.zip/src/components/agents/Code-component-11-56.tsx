import React, { useState } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";
import { ScrollArea } from "../ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  MapPin,
  Store,
  Users,
  Calendar,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Star,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  Clock,
  Target,
  DollarSign,
  Zap,
  Globe,
  Phone,
  Mail,
  ExternalLink,
  Search,
  Filter,
  Plus,
  Flag,
  Award,
  Building,
  Car,
  Coffee,
  ShoppingBag,
  Utensils,
  Wifi,
  Camera,
  Music,
  Gamepad2,
  Book,
  Briefcase,
  Home,
  TreePine,
  Activity,
  Bell,
  AlertTriangle,
  CheckCircle2,
  Hash
} from "lucide-react";

interface LocalBusiness {
  id: string;
  name: string;
  category: string;
  location: string;
  distance: number;
  rating: number;
  reviews: number;
  status: "competitor" | "partner" | "neutral";
  lastActivity: string;
  socialMentions: number;
  trend: "up" | "down" | "stable";
}

interface CommunityEvent {
  id: string;
  title: string;
  type: "networking" | "sponsorship" | "community" | "business";
  date: string;
  location: string;
  attendees: number;
  cost: number;
  opportunity: "high" | "medium" | "low";
  description: string;
}

interface LocalInfluencer {
  id: string;
  name: string;
  handle: string;
  platform: string;
  followers: number;
  engagement: number;
  location: string;
  niche: string[];
  recentPosts: number;
  availability: "available" | "busy" | "booked";
}

interface HashtagPerformance {
  tag: string;
  posts: number;
  reach: number;
  engagement: number;
  trend: "trending" | "stable" | "declining";
  localRelevance: number;
}

const mockLocalBusinesses: LocalBusiness[] = [
  {
    id: "1",
    name: "Downtown Tech Hub",
    category: "Coworking",
    location: "Downtown District",
    distance: 0.3,
    rating: 4.7,
    reviews: 134,
    status: "partner",
    lastActivity: "2024-12-10",
    socialMentions: 89,
    trend: "up"
  },
  {
    id: "2",
    name: "Innovate Coffee & Co",
    category: "Cafe",
    location: "Business Quarter",
    distance: 0.5,
    rating: 4.2,
    reviews: 267,
    status: "neutral",
    lastActivity: "2024-12-09",
    socialMentions: 156,
    trend: "stable"
  },
  {
    id: "3",
    name: "TechRival Solutions",
    category: "Technology",
    location: "Innovation Park",
    distance: 1.2,
    rating: 4.5,
    reviews: 89,
    status: "competitor",
    lastActivity: "2024-12-08",
    socialMentions: 234,
    trend: "up"
  }
];

const mockCommunityEvents: CommunityEvent[] = [
  {
    id: "1",
    title: "Small Business Networking Mixer",
    type: "networking",
    date: "2024-12-18",
    location: "Downtown Convention Center",
    attendees: 150,
    cost: 75,
    opportunity: "high",
    description: "Monthly networking event for local entrepreneurs and small business owners."
  },
  {
    id: "2",
    title: "Community Tech Festival",
    type: "sponsorship",
    date: "2024-12-22",
    location: "City Park Pavilion",
    attendees: 500,
    cost: 2500,
    opportunity: "high",
    description: "Annual technology showcase with sponsorship opportunities for local tech companies."
  },
  {
    id: "3",
    title: "Holiday Market Vendor Fair",
    type: "community",
    date: "2024-12-20",
    location: "Main Street Plaza",
    attendees: 300,
    cost: 150,
    opportunity: "medium",
    description: "Holiday shopping event featuring local vendors and artisans."
  }
];

const mockLocalInfluencers: LocalInfluencer[] = [
  {
    id: "1",
    name: "Sarah LocalLife",
    handle: "@sarahlocallife",
    platform: "Instagram",
    followers: 12400,
    engagement: 6.8,
    location: "Downtown Area",
    niche: ["Local Business", "Food", "Lifestyle"],
    recentPosts: 24,
    availability: "available"
  },
  {
    id: "2",
    name: "Mike CityExplorer",
    handle: "@mikecityexplorer",
    platform: "TikTok",
    followers: 8900,
    engagement: 8.2,
    location: "Arts District",
    niche: ["Local Events", "Entertainment", "Community"],
    recentPosts: 18,
    availability: "busy"
  },
  {
    id: "3",
    name: "Lisa BusinessLocal",
    handle: "@lisabusinesslocal",
    platform: "LinkedIn",
    followers: 5600,
    engagement: 4.5,
    location: "Business Quarter",
    niche: ["Business", "Networking", "Professional"],
    recentPosts: 12,
    availability: "available"
  }
];

const mockHashtagData: HashtagPerformance[] = [
  {
    tag: "#LocalBusiness",
    posts: 1847,
    reach: 89400,
    engagement: 6.7,
    trend: "trending",
    localRelevance: 94
  },
  {
    tag: "#CityLife",
    posts: 2341,
    reach: 156700,
    engagement: 5.2,
    trend: "stable",
    localRelevance: 87
  },
  {
    tag: "#SupportLocal",
    posts: 1234,
    reach: 67800,
    engagement: 7.8,
    trend: "trending",
    localRelevance: 96
  },
  {
    tag: "#TechHub",
    posts: 567,
    reach: 34500,
    engagement: 4.9,
    trend: "declining",
    localRelevance: 78
  }
];

export function LocalIntelligenceAgent() {
  const [activeTab, setActiveTab] = useState("market");
  const [selectedRadius, setSelectedRadius] = useState("5mi");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "partner": return "bg-success text-white";
      case "competitor": return "bg-destructive text-white";
      case "neutral": return "bg-muted text-muted-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getOpportunityColor = (opportunity: string) => {
    switch (opportunity) {
      case "high": return "text-success";
      case "medium": return "text-warning";
      case "low": return "text-muted-foreground";
      default: return "text-muted-foreground";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up": return <TrendingUp className="h-4 w-4 text-success" />;
      case "down": return <TrendingDown className="h-4 w-4 text-destructive" />;
      default: return <Activity className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getTrendingColor = (trend: string) => {
    switch (trend) {
      case "trending": return "text-success";
      case "declining": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "technology": return <Briefcase className="h-4 w-4" />;
      case "cafe": case "restaurant": return <Coffee className="h-4 w-4" />;
      case "retail": return <ShoppingBag className="h-4 w-4" />;
      case "coworking": return <Building className="h-4 w-4" />;
      default: return <Store className="h-4 w-4" />;
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 via-green-500 to-teal-500 text-white">
            <MapPin className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Local Market Intelligence</h2>
            <p className="text-muted-foreground">Hyperlocal insights and community engagement tools</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-sector-sme text-white">SME Focus</Badge>
          <Badge variant="outline">Real-time monitoring</Badge>
          <Button variant="outline" size="sm">
            <MapPin className="h-4 w-4 mr-2" />
            Change Location
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="market" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Local Market
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Events
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center gap-2">
            <Hash className="h-4 w-4" />
            Social Intel
          </TabsTrigger>
          <TabsTrigger value="partnerships" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Partnerships
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Local Campaigns
          </TabsTrigger>
        </TabsList>

        {/* Local Market Monitor */}
        <TabsContent value="market" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Local Business Intelligence</h3>
            <div className="flex items-center gap-2">
              <Select value={selectedRadius} onValueChange={setSelectedRadius}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1mi">1 mi</SelectItem>
                  <SelectItem value="5mi">5 mi</SelectItem>
                  <SelectItem value="10mi">10 mi</SelectItem>
                  <SelectItem value="25mi">25 mi</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="food">Food & Beverage</SelectItem>
                  <SelectItem value="services">Services</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center">
              <Store className="h-8 w-8 text-sector-sme mx-auto mb-2" />
              <div className="text-2xl font-bold">247</div>
              <div className="text-sm text-muted-foreground">Local Businesses</div>
              <Badge className="mt-2 bg-info text-white">5 mi radius</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Target className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">18</div>
              <div className="text-sm text-muted-foreground">Competitors</div>
              <Badge className="mt-2 bg-warning text-white">Direct</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Users className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">34</div>
              <div className="text-sm text-muted-foreground">Potential Partners</div>
              <Badge className="mt-2 bg-success text-white">High match</Badge>
            </Card>
            <Card className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">12.4%</div>
              <div className="text-sm text-muted-foreground">Market Growth</div>
              <Badge className="mt-2 bg-info text-white">YoY</Badge>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Nearby Businesses</h3>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>

              <div className="space-y-4">
                {mockLocalBusinesses.map((business) => (
                  <Card key={business.id} className="p-4 hover:shadow-omnidash-md transition-shadow">
                    <div className="flex items-start gap-4">
                      <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-teal-500/10">
                        {getCategoryIcon(business.category)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h4 className="font-medium">{business.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {business.category} • {business.distance} mi • {business.location}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(business.status)}>
                              {business.status}
                            </Badge>
                            {getTrendIcon(business.trend)}
                          </div>
                        </div>

                        <div className="flex items-center gap-6 mb-3">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-warning" />
                            <span className="text-sm font-medium">{business.rating}</span>
                            <span className="text-xs text-muted-foreground">({business.reviews} reviews)</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageCircle className="h-4 w-4 text-info" />
                            <span className="text-sm">{business.socialMentions} mentions</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              Updated {new Date(business.lastActivity).toLocaleDateString()}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-sm text-muted-foreground">
                            {business.status === "competitor" ? (
                              <span className="text-destructive">⚠ Monitor competitor activity</span>
                            ) : business.status === "partner" ? (
                              <span className="text-success">✓ Active partnership opportunity</span>
                            ) : (
                              <span>Potential collaboration target</span>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </Button>
                            <Button size="sm" className="bg-gradient-omnidash text-white">
                              <Mail className="h-4 w-4 mr-2" />
                              Connect
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Market Insights</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Technology Sector</span>
                    <Badge className="bg-success text-white">Growing</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Food & Beverage</span>
                    <Badge className="bg-info text-white">Stable</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Retail</span>
                    <Badge className="bg-warning text-white">Competitive</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Professional Services</span>
                    <Badge className="bg-success text-white">Opportunity</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Demographics</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Avg Household Income</span>
                    <span className="font-medium">$78K</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Age 25-45</span>
                    <span className="font-medium">47%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>College Educated</span>
                    <span className="font-medium">68%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tech Workers</span>
                    <span className="font-medium">23%</span>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Foot Traffic</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Peak Hours</span>
                    <span className="font-medium">11AM-2PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Busiest Day</span>
                    <span className="font-medium">Friday</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Weekend Traffic</span>
                    <span className="font-medium">+34%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Seasonal Trend</span>
                    <span className="font-medium text-success">↗ Growing</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Community Events Tracker */}
        <TabsContent value="events" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Community Events & Opportunities</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Calendar View
              </Button>
              <Button className="bg-gradient-omnidash text-white">
                <Plus className="h-4 w-4 mr-2" />
                Add Event
              </Button>
            </div>
          </div>

          <div className="grid gap-4">
            {mockCommunityEvents.map((event) => (
              <Card key={event.id} className="p-6 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-teal-500/10">
                      <Calendar className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg">{event.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {new Date(event.date).toLocaleDateString()} • {event.location}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="capitalize">{event.type}</Badge>
                    <Badge className={`bg-${event.opportunity === "high" ? "success" : event.opportunity === "medium" ? "warning" : "muted"} text-white`}>
                      {event.opportunity} opportunity
                    </Badge>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-4">{event.description}</p>

                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="font-semibold">{event.attendees}</div>
                    <div className="text-xs text-muted-foreground">Expected Attendees</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">${event.cost}</div>
                    <div className="text-xs text-muted-foreground">Participation Cost</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">
                      {Math.floor(Math.random() * 20) + 5}
                    </div>
                    <div className="text-xs text-muted-foreground">Local Businesses</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">
                      {Math.floor(Math.random() * 10) + 3} days
                    </div>
                    <div className="text-xs text-muted-foreground">Time to Event</div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    {event.opportunity === "high" ? (
                      <span className="text-success font-medium">🎯 High value networking opportunity</span>
                    ) : event.opportunity === "medium" ? (
                      <span className="text-warning">⚡ Good community visibility potential</span>
                    ) : (
                      <span>Standard community participation event</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      More Info
                    </Button>
                    <Button size="sm" className="bg-gradient-omnidash text-white">
                      <Flag className="h-4 w-4 mr-2" />
                      Register Interest
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Event Calendar</h3>
              <div className="h-64 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg">
                <div className="text-center">
                  <Calendar className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                  <p className="text-muted-foreground">Interactive event calendar</p>
                  <p className="text-sm text-muted-foreground">Monthly view with opportunity scoring and RSVP tracking</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Event ROI Tracker</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Networking Events</span>
                    <Badge className="bg-success text-white">+340% ROI</Badge>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Sponsorship Opportunities</span>
                    <Badge className="bg-info text-white">+220% ROI</Badge>
                  </div>
                  <Progress value={70} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Community Events</span>
                    <Badge className="bg-warning text-white">+150% ROI</Badge>
                  </div>
                  <Progress value={55} className="h-2" />
                </div>

                <Separator />

                <div className="text-sm">
                  <h5 className="font-medium mb-2">Best Performing Events</h5>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div>• Tech Meetups: 4.2x lead conversion</div>
                    <div>• Business Mixers: 3.8x partnership rate</div>
                    <div>• Community Festivals: 2.9x brand awareness</div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Local Social Intelligence */}
        <TabsContent value="social" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Local Social Media Intelligence</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Hash className="h-4 w-4 mr-2" />
                Trending Tags
              </Button>
              <Button className="bg-gradient-omnidash text-white">
                <Search className="h-4 w-4 mr-2" />
                Monitor Hashtag
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold text-lg mb-4">Hashtag Performance</h3>
              <div className="space-y-4">
                {mockHashtagData.map((hashtag, index) => (
                  <Card key={index} className="p-4 border-l-4 border-l-primary">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Hash className="h-5 w-5 text-primary" />
                        <span className="font-medium text-lg">{hashtag.tag}</span>
                        <Badge className={`text-xs ${getTrendingColor(hashtag.trend)}`} variant="outline">
                          {hashtag.trend}
                        </Badge>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{hashtag.localRelevance}%</div>
                        <div className="text-xs text-muted-foreground">Local Relevance</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-3">
                      <div className="text-center">
                        <div className="font-semibold">{formatNumber(hashtag.posts)}</div>
                        <div className="text-xs text-muted-foreground">Posts</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{formatNumber(hashtag.reach)}</div>
                        <div className="text-xs text-muted-foreground">Reach</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{hashtag.engagement}%</div>
                        <div className="text-xs text-muted-foreground">Engagement</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{hashtag.localRelevance}%</div>
                        <div className="text-xs text-muted-foreground">Relevance</div>
                      </div>
                    </div>

                    <Progress value={hashtag.localRelevance} className="h-2" />
                  </Card>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Local Influencers</h4>
                <div className="space-y-3">
                  {mockLocalInfluencers.map((influencer) => (
                    <div key={influencer.id} className="flex items-center gap-3 p-2 border rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-gradient-omnidash flex items-center justify-center text-white text-xs font-bold">
                        {influencer.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="flex-1">
                        <h5 className="font-medium text-sm">{influencer.name}</h5>
                        <p className="text-xs text-muted-foreground">
                          {formatNumber(influencer.followers)} followers • {influencer.engagement}% engagement
                        </p>
                      </div>
                      <Badge 
                        className={
                          influencer.availability === "available" ? "bg-success text-white" :
                          influencer.availability === "busy" ? "bg-warning text-white" :
                          "bg-destructive text-white"
                        }
                      >
                        {influencer.availability}
                      </Badge>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Customer Reviews</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Google Reviews</span>
                    <Badge className="bg-success text-white">4.7★</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Yelp Reviews</span>
                    <Badge className="bg-info text-white">4.5★</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Facebook Reviews</span>
                    <Badge className="bg-warning text-white">4.3★</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Overall Sentiment</span>
                    <Badge className="bg-success text-white">Positive</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Word-of-Mouth</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span>89 positive mentions this week</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-info" />
                    <span>Brand awareness up 23%</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-warning" />
                    <span>4.6/5 average recommendation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-success" />
                    <span>67% customer referral rate</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Partnership Opportunities */}
        <TabsContent value="partnerships" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Partnership Opportunities</h3>
            <Button className="bg-gradient-omnidash text-white">
              <Users className="h-4 w-4 mr-2" />
              Propose Partnership
            </Button>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Business Directory</h3>
              <div className="space-y-4">
                {mockLocalBusinesses.filter(b => b.status !== "competitor").map((business) => (
                  <Card key={business.id} className="p-4 border-l-4 border-l-success">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getCategoryIcon(business.category)}
                        <h4 className="font-medium">{business.name}</h4>
                      </div>
                      <Badge className="bg-success text-white">Match: 87%</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      {business.category} • {business.distance} mi away • {business.rating}★ rating
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        <span className="text-success font-medium">✓ High partnership potential</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" className="bg-gradient-omnidash text-white">
                          <Mail className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Collaboration Matcher</h3>
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="h-4 w-4 text-emerald-600" />
                    <span className="font-medium">AI Suggestion</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Partner with Downtown Tech Hub for cross-promotion. Complementary services with 89% audience overlap.
                  </p>
                  <div className="flex items-center justify-between">
                    <Badge className="bg-success text-white">High Potential</Badge>
                    <Button size="sm" variant="outline">Explore</Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h5 className="font-medium">Partnership Types</h5>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 border rounded">
                      <span className="text-sm">Cross-promotion</span>
                      <Badge variant="outline">8 opportunities</Badge>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded">
                      <span className="text-sm">Joint events</span>
                      <Badge variant="outline">5 opportunities</Badge>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded">
                      <span className="text-sm">Referral programs</span>
                      <Badge variant="outline">12 opportunities</Badge>
                    </div>
                    <div className="flex items-center justify-between p-2 border rounded">
                      <span className="text-sm">Bulk purchasing</span>
                      <Badge variant="outline">3 opportunities</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Partnership Success Tracking</h3>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-success">12</div>
                <div className="text-sm text-muted-foreground">Active Partnerships</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-info">340%</div>
                <div className="text-sm text-muted-foreground">Avg ROI</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-warning">67</div>
                <div className="text-sm text-muted-foreground">Referrals Generated</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">$24K</div>
                <div className="text-sm text-muted-foreground">Revenue Attributed</div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Local Campaigns */}
        <TabsContent value="campaigns" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Hyperlocal Marketing Campaigns</h3>
            <Button className="bg-gradient-omnidash text-white">
              <Target className="h-4 w-4 mr-2" />
              Create Campaign
            </Button>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Geo-targeted Advertising</h3>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium">Downtown Business District</h5>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Targeting professionals within 0.5 miles during lunch hours
                  </p>
                  <div className="grid grid-cols-3 gap-3 text-center text-sm">
                    <div>
                      <div className="font-semibold">2.4K</div>
                      <div className="text-xs text-muted-foreground">Impressions</div>
                    </div>
                    <div>
                      <div className="font-semibold">6.7%</div>
                      <div className="text-xs text-muted-foreground">CTR</div>
                    </div>
                    <div>
                      <div className="font-semibold">$0.23</div>
                      <div className="text-xs text-muted-foreground">CPC</div>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium">Residential Areas</h5>
                    <Badge className="bg-info text-white">Planned</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Weekend campaigns targeting families within 2 miles
                  </p>
                  <div className="grid grid-cols-3 gap-3 text-center text-sm">
                    <div>
                      <div className="font-semibold">Est. 5.2K</div>
                      <div className="text-xs text-muted-foreground">Reach</div>
                    </div>
                    <div>
                      <div className="font-semibold">$250</div>
                      <div className="text-xs text-muted-foreground">Budget</div>
                    </div>
                    <div>
                      <div className="font-semibold">Dec 16</div>
                      <div className="text-xs text-muted-foreground">Launch</div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Local SEO Optimizer</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Google My Business</span>
                    <Badge className="bg-success text-white">Optimized</Badge>
                  </div>
                  <Progress value={95} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Local Keywords</span>
                    <Badge className="bg-warning text-white">Improving</Badge>
                  </div>
                  <Progress value={73} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Local Citations</span>
                    <Badge className="bg-info text-white">Good</Badge>
                  </div>
                  <Progress value={82} className="h-2" />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Review Management</span>
                    <Badge className="bg-success text-white">Excellent</Badge>
                  </div>
                  <Progress value={91} className="h-2" />
                </div>

                <Separator />

                <div className="text-sm">
                  <h5 className="font-medium mb-2">Local Search Rankings</h5>
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span>"tech services downtown"</span>
                      <Badge variant="outline">#3</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>"business consulting local"</span>
                      <Badge variant="outline">#7</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>"ai solutions nearby"</span>
                      <Badge variant="outline">#2</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Neighborhood Marketing Performance</h3>
            <div className="h-64 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-emerald-500 mx-auto mb-4" />
                <p className="text-muted-foreground">Geographic performance visualization</p>
                <p className="text-sm text-muted-foreground">Hyperlocal campaign effectiveness by neighborhood and demographic segment</p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}