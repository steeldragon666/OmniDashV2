import React, { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { ScrollArea } from "../ui/scroll-area";
import { Separator } from "../ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Bot,
  Sparkles,
  Calendar,
  Play,
  Pause,
  Edit3,
  Send,
  Copy,
  ThumbsUp,
  ThumbsDown,
  BarChart3,
  TrendingUp,
  Users,
  Globe,
  Instagram,
  Twitter,
  Facebook,
  Linkedin,
  Youtube,
  Clock,
  Target,
  Zap,
  CheckCircle2,
  AlertCircle,
  Star,
  Eye,
  Heart,
  MessageCircle,
  Share2
} from "lucide-react";

interface ContentPiece {
  id: string;
  title: string;
  content: string;
  platform: string[];
  status: "draft" | "scheduled" | "published" | "approved";
  engagement?: {
    likes: number;
    comments: number;
    shares: number;
    reach: number;
  };
  scheduledFor?: string;
  createdAt: string;
}

const mockContentPieces: ContentPiece[] = [
  {
    id: "1",
    title: "Q4 Product Launch Announcement",
    content: "🚀 Exciting news! Our latest AI-powered features are launching this quarter. Get ready to transform your business intelligence like never before...",
    platform: ["LinkedIn", "Twitter", "Facebook"],
    status: "scheduled",
    scheduledFor: "2024-12-15T10:00:00",
    createdAt: "2024-12-10T08:30:00"
  },
  {
    id: "2", 
    title: "Customer Success Story",
    content: "How TechCorp increased their revenue by 340% using OmniDash AI intelligence platform. Read their amazing transformation story...",
    platform: ["LinkedIn", "Instagram"],
    status: "published",
    engagement: {
      likes: 1247,
      comments: 89,
      shares: 156,
      reach: 12840
    },
    createdAt: "2024-12-08T14:20:00"
  },
  {
    id: "3",
    title: "Weekly Industry Insights",
    content: "This week in AI: Major breakthroughs in enterprise intelligence, government adoption trends, and what it means for SME growth...",
    platform: ["Twitter", "LinkedIn"],
    status: "draft",
    createdAt: "2024-12-10T16:45:00"
  }
];

export function ContentAgent() {
  const [prompt, setPrompt] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [contentType, setContentType] = useState("post");
  const [brandVoice, setBrandVoice] = useState("professional");
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState("create");

  const platforms = [
    { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "text-blue-600" },
    { id: "twitter", name: "Twitter", icon: Twitter, color: "text-sky-500" },
    { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-700" },
    { id: "instagram", name: "Instagram", icon: Instagram, color: "text-pink-600" },
    { id: "youtube", name: "YouTube", icon: Youtube, color: "text-red-600" }
  ];

  const contentTypes = [
    { id: "post", name: "Social Media Post", description: "Engaging posts for social platforms" },
    { id: "blog", name: "Blog Article", description: "Long-form content for websites" },
    { id: "email", name: "Email Campaign", description: "Newsletter and promotional emails" },
    { id: "video", name: "Video Script", description: "Scripts for video content" },
    { id: "ad", name: "Advertisement", description: "Paid promotional content" }
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate AI generation
    setTimeout(() => {
      setIsGenerating(false);
      setActiveTab("preview");
    }, 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-omnidash text-white glow-orange">
            <Bot className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-brand-navy">Content Generation Studio</h2>
            <p className="text-muted-foreground">AI-powered content creation and social publishing</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-electric-lime text-brand-navy font-semibold">
            <div className="w-2 h-2 rounded-full bg-brand-navy animate-pulse mr-2"></div>
            Online
          </Badge>
          <Badge className="bg-brand-navy text-electric-lime border-electric-lime">2,847 pieces generated</Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="create" className="flex items-center gap-2">
            <Sparkles className="h-4 w-4" />
            Create
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Preview
          </TabsTrigger>
          <TabsTrigger value="calendar" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Schedule
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Content Creation Studio */}
        <TabsContent value="create" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Content Input */}
            <Card className="lg:col-span-2 p-6 bg-gradient-to-br from-background to-brand-navy/5 border-l-4 border-l-brand-orange hover-glow-orange">
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-lg mb-4 text-brand-navy">Content Creation</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">What would you like to create?</label>
                      <Textarea
                        placeholder="Describe the content you want to generate... (e.g., 'Create a LinkedIn post about our new AI features that highlights customer benefits and includes a call-to-action')"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="min-h-32 resize-none bg-background border-2 focus:border-primary"
                      />
                    </div>

                    {/* Content Type Selection */}
                    <div className="grid grid-cols-2 gap-3">
                      {contentTypes.map((type) => (
                        <Button
                          key={type.id}
                          variant={contentType === type.id ? "default" : "outline"}
                          onClick={() => setContentType(type.id)}
                          className="h-auto p-4 flex-col items-start text-left"
                        >
                          <span className="font-medium">{type.name}</span>
                          <span className="text-xs text-muted-foreground">{type.description}</span>
                        </Button>
                      ))}
                    </div>

                    {/* Platform Selection */}
                    <div>
                      <label className="block text-sm font-medium mb-3">Target Platforms</label>
                      <div className="grid grid-cols-5 gap-2">
                        {platforms.map((platform) => {
                          const Icon = platform.icon;
                          const isSelected = selectedPlatforms.includes(platform.id);
                          return (
                            <Button
                              key={platform.id}
                              variant={isSelected ? "default" : "outline"}
                              size="icon"
                              onClick={() => {
                                setSelectedPlatforms(prev =>
                                  isSelected
                                    ? prev.filter(p => p !== platform.id)
                                    : [...prev, platform.id]
                                );
                              }}
                              className="h-12 w-12"
                            >
                              <Icon className={`h-5 w-5 ${isSelected ? 'text-white' : platform.color}`} />
                            </Button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Brand Voice Settings */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Brand Voice</label>
                        <Select value={brandVoice} onValueChange={setBrandVoice}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="professional">Professional</SelectItem>
                            <SelectItem value="friendly">Friendly</SelectItem>
                            <SelectItem value="authoritative">Authoritative</SelectItem>
                            <SelectItem value="casual">Casual</SelectItem>
                            <SelectItem value="technical">Technical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Content Length</label>
                        <Select defaultValue="medium">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="short">Short (1-2 sentences)</SelectItem>
                            <SelectItem value="medium">Medium (1-2 paragraphs)</SelectItem>
                            <SelectItem value="long">Long (3+ paragraphs)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button 
                      onClick={handleGenerate}
                      disabled={!prompt || isGenerating}
                      className="w-full bg-gradient-omnidash text-white hover:opacity-90 h-12 hover-glow-orange font-semibold"
                    >
                      {isGenerating ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4 mr-2" />
                          Generate Content
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Quick Actions & Settings */}
            <div className="space-y-4">
              <Card className="p-4 border-l-4 border-l-electric-lime hover-glow-lime">
                <h4 className="font-medium mb-3 text-brand-navy">Quick Actions</h4>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <Bot className="h-4 w-4 mr-2" />
                    Generate Blog Post
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Target className="h-4 w-4 mr-2" />
                    Create Campaign Series
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Zap className="h-4 w-4 mr-2" />
                    Generate Video Script
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Send className="h-4 w-4 mr-2" />
                    Email Newsletter
                  </Button>
                </div>
              </Card>

              <Card className="p-4 border-l-4 border-l-hot-pink hover-glow-pink">
                <h4 className="font-medium mb-3 text-brand-navy">Content Performance</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Engagement Rate</span>
                    <Badge className="bg-electric-lime text-brand-navy font-semibold">+23%</Badge>
                  </div>
                  <Progress value={87} className="h-2" />
                  <div className="text-xs text-muted-foreground">87% above average</div>
                </div>
              </Card>

              <Card className="p-4 border-l-4 border-l-electric-yellow">
                <h4 className="font-medium mb-3 text-brand-navy">AI Insights</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <TrendingUp className="h-4 w-4 text-electric-lime mt-0.5" />
                    <span>LinkedIn posts perform 40% better with industry hashtags</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Clock className="h-4 w-4 text-ice-blue mt-0.5" />
                    <span>Best posting time: Tue-Thu 10:00-11:00 AM</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Users className="h-4 w-4 text-brand-orange mt-0.5" />
                    <span>Questions increase engagement by 60%</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Content Preview */}
        <TabsContent value="preview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Generated Content</h3>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  <Button size="sm" variant="outline">
                    <Edit3 className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm leading-relaxed">
                    🚀 Exciting milestone alert! We've just crossed 10,000 active users on the OmniDash platform. 
                    
                    From SME startups to government agencies, businesses worldwide are transforming their decision-making with AI-powered intelligence.
                    
                    What started as a vision to democratize enterprise-grade AI has become a reality that's driving:
                    ✨ 340% average revenue growth
                    ✨ 87% reduction in manual analysis time  
                    ✨ 94% improvement in strategic decision accuracy
                    
                    Ready to join the intelligence revolution? 
                    
                    #AIIntelligence #BusinessTransformation #OmniDash
                  </p>
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Words: 156</span>
                  <span>Characters: 847</span>
                  <span>Hashtags: 3</span>
                  <span>Mentions: 1</span>
                </div>

                <div className="flex items-center gap-2">
                  <Button size="sm" className="bg-success text-white">
                    <ThumbsUp className="h-4 w-4 mr-2" />
                    Approve
                  </Button>
                  <Button size="sm" variant="outline">
                    <ThumbsDown className="h-4 w-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Platform Previews</h4>
                <div className="space-y-3">
                  {selectedPlatforms.length > 0 ? selectedPlatforms.map(platformId => {
                    const platform = platforms.find(p => p.id === platformId);
                    if (!platform) return null;
                    const Icon = platform.icon;
                    return (
                      <div key={platformId} className="flex items-center gap-3 p-3 border rounded-lg">
                        <Icon className={`h-5 w-5 ${platform.color}`} />
                        <div className="flex-1">
                          <div className="font-medium">{platform.name}</div>
                          <div className="text-xs text-muted-foreground">Optimized for {platform.name.toLowerCase()}</div>
                        </div>
                        <Badge variant="outline" className="text-xs">Ready</Badge>
                      </div>
                    );
                  }) : (
                    <div className="text-center text-muted-foreground py-4">
                      Select platforms to see previews
                    </div>
                  )}
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Engagement Prediction</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Viral Potential</span>
                    <Badge className="bg-info text-white">High</Badge>
                  </div>
                  <Progress value={76} className="h-2" />
                  <div className="text-xs text-muted-foreground">76% likelihood of above-average engagement</div>
                  
                  <Separator />
                  
                  <div className="grid grid-cols-2 gap-3 text-center">
                    <div>
                      <div className="text-lg font-semibold">2.4K</div>
                      <div className="text-xs text-muted-foreground">Est. Reach</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold">180</div>
                      <div className="text-xs text-muted-foreground">Est. Engagement</div>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Content Calendar */}
        <TabsContent value="calendar" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold text-lg mb-4">Content Calendar</h3>
              <div className="space-y-4">
                {mockContentPieces.map((piece) => (
                  <div key={piece.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex-1">
                      <h4 className="font-medium">{piece.title}</h4>
                      <p className="text-sm text-muted-foreground truncate">{piece.content}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {piece.platform.map((platform) => (
                          <Badge key={platform} variant="outline" className="text-xs">{platform}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge 
                        className={`mb-2 ${
                          piece.status === 'published' ? 'bg-success text-white' :
                          piece.status === 'scheduled' ? 'bg-info text-white' :
                          piece.status === 'approved' ? 'bg-warning text-white' :
                          'bg-muted text-muted-foreground'
                        }`}
                      >
                        {piece.status}
                      </Badge>
                      <div className="text-xs text-muted-foreground">
                        {piece.scheduledFor ? 
                          `Scheduled: ${new Date(piece.scheduledFor).toLocaleDateString()}` :
                          `Created: ${new Date(piece.createdAt).toLocaleDateString()}`
                        }
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost">
                        <Edit3 className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost">
                        <Calendar className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Publishing Queue</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Scheduled Posts</span>
                    <Badge variant="outline">12</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Drafts</span>
                    <Badge variant="outline">8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Pending Approval</span>
                    <Badge variant="outline">3</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Optimal Timing</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>LinkedIn</span>
                    <span className="text-muted-foreground">Tue 10:00 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Twitter</span>
                    <span className="text-muted-foreground">Wed 2:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Instagram</span>
                    <span className="text-muted-foreground">Fri 6:00 PM</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center border-l-4 border-l-hot-pink hover-glow-pink transition-all duration-300">
              <Heart className="h-8 w-8 text-hot-pink mx-auto mb-2" />
              <div className="text-2xl font-bold text-brand-navy">2,847</div>
              <div className="text-sm text-muted-foreground">Total Likes</div>
              <Badge className="mt-2 bg-electric-lime text-brand-navy font-semibold">+18%</Badge>
            </Card>
            <Card className="p-4 text-center border-l-4 border-l-ice-blue transition-all duration-300">
              <MessageCircle className="h-8 w-8 text-ice-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-brand-navy">592</div>
              <div className="text-sm text-muted-foreground">Comments</div>
              <Badge className="mt-2 bg-electric-lime text-brand-navy font-semibold">+25%</Badge>
            </Card>
            <Card className="p-4 text-center border-l-4 border-l-electric-yellow transition-all duration-300">
              <Share2 className="h-8 w-8 text-electric-yellow mx-auto mb-2" />
              <div className="text-2xl font-bold text-brand-navy">1,103</div>
              <div className="text-sm text-muted-foreground">Shares</div>
              <Badge className="mt-2 bg-electric-lime text-brand-navy font-semibold">+31%</Badge>
            </Card>
            <Card className="p-4 text-center border-l-4 border-l-brand-orange hover-glow-orange transition-all duration-300">
              <Eye className="h-8 w-8 text-brand-orange mx-auto mb-2" />
              <div className="text-2xl font-bold text-brand-navy">24.8K</div>
              <div className="text-sm text-muted-foreground">Reach</div>
              <Badge className="mt-2 bg-electric-lime text-brand-navy font-semibold">+42%</Badge>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Performance Trends</h3>
              <div className="h-64 flex items-center justify-center bg-muted/50 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">Chart visualization would go here</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Top Performing Content</h3>
              <div className="space-y-3">
                {mockContentPieces.filter(p => p.engagement).map((piece) => (
                  <div key={piece.id} className="flex items-center gap-3 p-3 border rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{piece.title}</h4>
                      <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                        <span>{piece.engagement?.likes} likes</span>
                        <span>{piece.engagement?.comments} comments</span>
                        <span>{piece.engagement?.reach} reach</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 text-yellow-500" />
                        <span className="text-xs">Top</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}