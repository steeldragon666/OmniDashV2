import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    period: string;
  };
  trend?: "positive" | "negative" | "neutral";
  icon?: React.ReactNode;
  sector?: "sme" | "government" | "enterprise";
  badge?: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function MetricCard({
  title,
  value,
  change,
  trend = "neutral",
  icon,
  sector,
  badge,
  size = "md",
  className = ""
}: MetricCardProps) {
  const sizeClasses = {
    sm: "p-4",
    md: "p-6",
    lg: "p-8"
  };

  const valueSizeClasses = {
    sm: "text-xl",
    md: "text-2xl", 
    lg: "text-3xl"
  };

  const getTrendIcon = () => {
    if (trend === "positive") return <TrendingUp className="h-4 w-4" />;
    if (trend === "negative") return <TrendingDown className="h-4 w-4" />;
    return <Minus className="h-4 w-4" />;
  };

  const getTrendColor = () => {
    if (trend === "positive") return "text-success";
    if (trend === "negative") return "text-destructive";
    return "text-muted-foreground";
  };

  const getSectorColor = () => {
    switch (sector) {
      case "sme": return "bg-sector-sme";
      case "government": return "bg-sector-government";
      case "enterprise": return "bg-sector-enterprise";
      default: return "bg-primary";
    }
  };

  return (
    <Card className={`${sizeClasses[size]} ${className} hover:shadow-omnidash-md transition-shadow`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <p className="text-sm text-muted-foreground">{title}</p>
            {badge && (
              <Badge variant="outline" className="text-xs">
                {badge}
              </Badge>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <p className={`${valueSizeClasses[size]} font-bold text-foreground`}>
              {value}
            </p>
            {change && (
              <div className={`flex items-center gap-1 ${getTrendColor()}`}>
                {getTrendIcon()}
                <span className="text-sm font-medium">
                  {change.value > 0 ? "+" : ""}{change.value}%
                </span>
                <span className="text-xs text-muted-foreground">
                  {change.period}
                </span>
              </div>
            )}
          </div>
        </div>
        {icon && (
          <div className={`${getSectorColor()} p-2 rounded-lg flex-shrink-0`}>
            <div className="text-white">
              {icon}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}