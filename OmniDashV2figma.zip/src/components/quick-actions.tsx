import { Plus, Zap, BarChart3, FileText, Users, Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface QuickActionsProps {
  sector: "sme" | "government" | "enterprise";
  onAction: (action: string) => void;
  className?: string;
}

export function QuickActions({ sector, onAction, className = "" }: QuickActionsProps) {
  const getQuickActions = () => {
    const baseActions = [
      { id: "create-content", label: "Create Content", icon: FileText, color: "bg-brand-blue" },
      { id: "analyze-data", label: "Analyze Data", icon: BarChart3, color: "bg-brand-purple" },
      { id: "schedule-post", label: "Schedule Post", icon: Calendar, color: "bg-success" },
    ];

    switch (sector) {
      case "sme":
        return [
          ...baseActions,
          { id: "local-insights", label: "Local Insights", icon: Zap, color: "bg-sector-sme" },
          { id: "competitor-analysis", label: "Competitor Analysis", icon: Users, color: "bg-warning" },
        ];
      
      case "government":
        return [
          ...baseActions,
          { id: "compliance-check", label: "Compliance Check", icon: Zap, color: "bg-sector-government" },
          { id: "policy-impact", label: "Policy Impact", icon: Users, color: "bg-info" },
        ];
      
      case "enterprise":
        return [
          ...baseActions,
          { id: "multi-brand", label: "Multi-Brand View", icon: Zap, color: "bg-sector-enterprise" },
          { id: "team-insights", label: "Team Insights", icon: Users, color: "bg-brand-purple" },
        ];
      
      default:
        return baseActions;
    }
  };

  const actions = getQuickActions();

  return (
    <Card className={`p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Quick Actions</h3>
        <Button variant="ghost" size="sm">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {actions.map((action) => (
          <Button
            key={action.id}
            variant="outline"
            className="h-auto p-4 flex flex-col items-center gap-2 hover:bg-muted/50 transition-colors"
            onClick={() => onAction(action.id)}
          >
            <div className={`${action.color} p-2 rounded-lg`}>
              <action.icon className="h-4 w-4 text-white" />
            </div>
            <span className="text-xs text-center">{action.label}</span>
          </Button>
        ))}
      </div>
    </Card>
  );
}