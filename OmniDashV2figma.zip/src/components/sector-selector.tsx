import { Building, MapPin, Users } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface SectorSelectorProps {
  currentSector: "sme" | "government" | "enterprise";
  onSectorChange: (sector: "sme" | "government" | "enterprise") => void;
  className?: string;
}

export function SectorSelector({ 
  currentSector, 
  onSectorChange, 
  className = "" 
}: SectorSelectorProps) {
  const sectors = [
    {
      id: "sme" as const,
      name: "Small & Medium Enterprise",
      description: "Local business intelligence and growth tools",
      icon: MapPin,
      color: "bg-sector-sme",
      lightColor: "bg-sector-sme-light",
      features: ["Local Intelligence", "Content Creation", "Social Media Management"]
    },
    {
      id: "government" as const,
      name: "Government & Public Sector",
      description: "Compliance-focused intelligence and public sector tools",
      icon: Building,
      color: "bg-sector-government",
      lightColor: "bg-sector-government-light",
      features: ["Compliance Monitoring", "Public Sentiment", "Policy Impact Analysis"]
    },
    {
      id: "enterprise" as const,
      name: "Enterprise & Corporate",
      description: "Advanced analytics and multi-brand management",
      icon: Users,
      color: "bg-sector-enterprise",
      lightColor: "bg-sector-enterprise-light",
      features: ["Advanced Analytics", "Multi-Brand Management", "Team Collaboration"]
    }
  ];

  return (
    <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 ${className}`}>
      {sectors.map((sector) => {
        const isSelected = currentSector === sector.id;
        
        return (
          <Card
            key={sector.id}
            className={`p-6 cursor-pointer transition-all duration-200 hover:shadow-omnidash-md ${
              isSelected 
                ? "ring-2 ring-primary bg-primary/5" 
                : "hover:bg-muted/30"
            }`}
            onClick={() => onSectorChange(sector.id)}
          >
            {/* Header */}
            <div className="flex items-start gap-4 mb-4">
              <div className={`${sector.color} p-3 rounded-lg flex-shrink-0`}>
                <sector.icon className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-foreground">{sector.name}</h3>
                {isSelected && (
                  <Badge className="mt-2 bg-primary text-white">
                    Current Platform
                  </Badge>
                )}
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4">
              {sector.description}
            </p>

            {/* Features */}
            <div className="space-y-2">
              <p className="text-xs font-medium text-foreground">Key Features:</p>
              <div className="flex flex-wrap gap-1">
                {sector.features.map((feature, index) => (
                  <Badge 
                    key={index}
                    variant="outline"
                    className="text-xs"
                  >
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}