import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { ScrollArea } from "./ui/scroll-area";
import { 
  Bot, 
  FileText, 
  TrendingUp, 
  Users, 
  Shield, 
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Info
} from "lucide-react";

interface ActivityItem {
  id: string;
  type: "agent" | "content" | "analytics" | "compliance" | "system";
  title: string;
  description: string;
  timestamp: string;
  status?: "success" | "warning" | "error" | "info";
  agent?: string;
}

interface ActivityFeedProps {
  activities?: ActivityItem[];
  className?: string;
}

export function ActivityFeed({ activities, className = "" }: ActivityFeedProps) {
  const defaultActivities: ActivityItem[] = [
    {
      id: "1",
      type: "agent",
      title: "Content Agent Generated New Post",
      description: "Created social media content for Q4 campaign",
      timestamp: "2 minutes ago",
      status: "success",
      agent: "Content Agent"
    },
    {
      id: "2", 
      type: "analytics",
      title: "Weekly Analytics Report Ready",
      description: "Performance metrics show 23% increase in engagement",
      timestamp: "15 minutes ago",
      status: "info"
    },
    {
      id: "3",
      type: "agent",
      title: "Influencer Agent Found New Partners",
      description: "Identified 3 potential collaborators in your sector",
      timestamp: "1 hour ago",
      status: "success",
      agent: "Influencer Agent"
    },
    {
      id: "4",
      type: "compliance",
      title: "Compliance Check Completed",
      description: "All content passed regulatory requirements",
      timestamp: "2 hours ago",
      status: "success"
    },
    {
      id: "5",
      type: "system",
      title: "System Update Available",
      description: "New AI model improvements ready for deployment",
      timestamp: "3 hours ago",
      status: "info"
    },
    {
      id: "6",
      type: "agent",
      title: "Revenue Agent Alert",
      description: "Detected unusual pattern in sales pipeline",
      timestamp: "4 hours ago",
      status: "warning",
      agent: "Revenue Agent"
    }
  ];

  const activityData = activities || defaultActivities;

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "agent": return Bot;
      case "content": return FileText;
      case "analytics": return TrendingUp;
      case "compliance": return Shield;
      case "system": return Calendar;
      default: return Info;
    }
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "success": return CheckCircle2;
      case "warning": return AlertTriangle;
      case "error": return AlertTriangle;
      case "info": return Info;
      default: return Info;
    }
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case "success": return "text-success";
      case "warning": return "text-warning";
      case "error": return "text-destructive";
      case "info": return "text-info";
      default: return "text-muted-foreground";
    }
  };

  return (
    <Card className={`p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Recent Activity</h3>
        <Badge variant="outline" className="text-xs">
          {activityData.length} updates
        </Badge>
      </div>

      <ScrollArea className="h-80">
        <div className="space-y-4">
          {activityData.map((activity) => {
            const TypeIcon = getTypeIcon(activity.type);
            const StatusIcon = getStatusIcon(activity.status);
            
            return (
              <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/30 transition-colors">
                {/* Icon */}
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-primary/10">
                    <TypeIcon className="h-4 w-4 text-primary" />
                  </AvatarFallback>
                </Avatar>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-foreground">{activity.title}</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {activity.description}
                      </p>
                      {activity.agent && (
                        <Badge variant="outline" className="mt-2 text-xs">
                          {activity.agent}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <StatusIcon className={`h-4 w-4 ${getStatusColor(activity.status)}`} />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    {activity.timestamp}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </Card>
  );
}