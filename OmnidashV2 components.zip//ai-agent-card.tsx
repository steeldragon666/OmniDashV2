import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Bot, Play, Settings, MoreHorizontal } from "lucide-react";

interface AIAgentCardProps {
  name: string;
  description: string;
  status: "active" | "inactive" | "training" | "paused";
  type: "content" | "sales" | "crm" | "influencer" | "sentiment" | "revenue" | "strategy" | "compliance" | "public-sector" | "local-intelligence";
  metrics?: {
    label: string;
    value: string;
  }[];
  lastActive?: string;
  onActivate?: () => void;
  onConfigure?: () => void;
  className?: string;
}

export function AIAgentCard({
  name,
  description,
  status,
  type,
  metrics = [],
  lastActive,
  onActivate,
  onConfigure,
  className = ""
}: AIAgentCardProps) {
  const getStatusColor = () => {
    switch (status) {
      case "active": return "bg-success text-white";
      case "inactive": return "bg-muted text-muted-foreground";
      case "training": return "bg-warning text-white";
      case "paused": return "bg-info text-white";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getTypeColor = () => {
    switch (type) {
      case "content": return "bg-brand-blue";
      case "sales": return "bg-success";
      case "crm": return "bg-brand-purple";
      case "influencer": return "bg-sector-enterprise";
      case "sentiment": return "bg-info";
      case "revenue": return "bg-success";
      case "strategy": return "bg-brand-purple";
      case "compliance": return "bg-destructive";
      case "public-sector": return "bg-sector-government";
      case "local-intelligence": return "bg-sector-sme";
      default: return "bg-primary";
    }
  };

  const getStatusText = () => {
    switch (status) {
      case "active": return "Active";
      case "inactive": return "Inactive";
      case "training": return "Training";
      case "paused": return "Paused";
      default: return "Unknown";
    }
  };

  return (
    <Card className={`p-6 hover:shadow-omnidash-md transition-all duration-200 ${className}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`${getTypeColor()} p-2 rounded-lg flex-shrink-0`}>
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <Badge className={`text-xs ${getStatusColor()}`}>
                {getStatusText()}
              </Badge>
              <Badge variant="outline" className="text-xs capitalize">
                {type.replace("-", " ")}
              </Badge>
            </div>
          </div>
        </div>
        <Button variant="ghost" size="sm">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </div>

      {/* Description */}
      <p className="text-sm text-muted-foreground mb-4">
        {description}
      </p>

      {/* Metrics */}
      {metrics.length > 0 && (
        <div className="grid grid-cols-2 gap-4 mb-4">
          {metrics.map((metric, index) => (
            <div key={index} className="text-center">
              <p className="text-xs text-muted-foreground">{metric.label}</p>
              <p className="text-sm font-semibold text-foreground">{metric.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Last Active */}
      {lastActive && (
        <p className="text-xs text-muted-foreground mb-4">
          Last active: {lastActive}
        </p>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button 
          onClick={onActivate}
          className="flex-1"
          disabled={status === "active"}
        >
          <Play className="h-4 w-4 mr-2" />
          {status === "active" ? "Running" : "Activate"}
        </Button>
        <Button variant="outline" onClick={onConfigure}>
          <Settings className="h-4 w-4" />
        </Button>
      </div>
    </Card>
  );
}