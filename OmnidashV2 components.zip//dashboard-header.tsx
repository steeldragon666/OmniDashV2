import { Bell, Search, User, Settings, LogOut } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

interface DashboardHeaderProps {
  title: string;
  subtitle?: string;
  sector: "sme" | "government" | "enterprise";
  user?: {
    name: string;
    email: string;
    avatar?: string;
    initials: string;
  };
  notifications?: number;
  onSearch?: (query: string) => void;
  className?: string;
}

export function DashboardHeader({
  title,
  subtitle,
  sector,
  user = {
    name: "Alex Thompson",
    email: "alex@example.com",
    initials: "AT"
  },
  notifications = 3,
  onSearch,
  className = ""
}: DashboardHeaderProps) {
  const getSectorColor = () => {
    switch (sector) {
      case "sme": return "border-sector-sme";
      case "government": return "border-sector-government"; 
      case "enterprise": return "border-sector-enterprise";
      default: return "border-primary";
    }
  };

  return (
    <header className={`bg-card border-b border-border px-6 py-4 ${className}`}>
      <div className="flex items-center justify-between">
        {/* Left section - Title */}
        <div className={`border-l-4 ${getSectorColor()} pl-4`}>
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          {subtitle && (
            <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>

        {/* Right section - Search & User */}
        <div className="flex items-center gap-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search agents, data, insights..."
              className="pl-10 w-80 bg-muted/30 border-muted focus:bg-background transition-colors"
              onChange={(e) => onSearch?.(e.target.value)}
            />
          </div>

          {/* Notifications */}
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            {notifications > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-destructive text-white text-xs">
                {notifications > 9 ? "9+" : notifications}
              </Badge>
            )}
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-3 pl-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                    {user.initials}
                  </AvatarFallback>
                </Avatar>
                <div className="text-left hidden md:block">
                  <p className="text-sm font-medium text-foreground">{user.name}</p>
                  <p className="text-xs text-muted-foreground">{user.email}</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}