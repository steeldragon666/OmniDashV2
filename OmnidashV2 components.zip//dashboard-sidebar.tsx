import { useState } from "react";
import { OmniDashLogo } from "./omnidash-logo";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Separator } from "./ui/separator";
import { 
  LayoutDashboard, 
  Bot, 
  BarChart3, 
  Users, 
  Settings, 
  Search,
  FileText,
  Target,
  DollarSign,
  Shield,
  Building,
  MapPin,
  Brain,
  TrendingUp,
  MessageSquare,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Zap
} from "lucide-react";

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  sector: "sme" | "government" | "enterprise";
  className?: string;
}

export function DashboardSidebar({ 
  currentView, 
  onViewChange, 
  sector,
  className = "" 
}: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const navigationItems = [
    {
      group: "Overview",
      items: [
        { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, badge: null },
        { id: "analytics", label: "Analytics", icon: BarChart3, badge: "New" },
      ]
    },
    {
      group: "AI Agents",
      items: [
        { id: "content-agent", label: "Content Agent", icon: FileText, badge: null },
        { id: "sales-agent", label: "Sales Agent", icon: Target, badge: "Active" },
        { id: "crm-agent", label: "CRM Agent", icon: Users, badge: null },
        { id: "influencer-agent", label: "Influencer Agent", icon: TrendingUp, badge: null },
        { id: "sentiment-agent", label: "Sentiment Agent", icon: MessageSquare, badge: null },
        { id: "revenue-agent", label: "Revenue Agent", icon: DollarSign, badge: "Beta" },
      ]
    },
    {
      group: "Intelligence",
      items: [
        { id: "strategy-agent", label: "Strategy Agent", icon: Brain, badge: "AI" },
        { id: "compliance-agent", label: "Compliance Agent", icon: Shield, badge: null },
        ...(sector === "government" ? [
          { id: "public-sector", label: "Public Sector Tools", icon: Building, badge: "Gov" }
        ] : []),
        ...(sector === "sme" ? [
          { id: "local-intelligence", label: "Local Intelligence", icon: MapPin, badge: "Local" }
        ] : []),
      ]
    },
    {
      group: "Management",
      items: [
        { id: "workflows", label: "Workflows", icon: Zap, badge: null },
        { id: "calendar", label: "Calendar", icon: Calendar, badge: null },
        { id: "search", label: "Search", icon: Search, badge: null },
        { id: "settings", label: "Settings", icon: Settings, badge: null },
      ]
    }
  ];

  const getSectorColor = () => {
    switch (sector) {
      case "sme": return "text-sector-sme";
      case "government": return "text-sector-government";
      case "enterprise": return "text-sector-enterprise";
      default: return "text-primary";
    }
  };

  const getSectorBadgeColor = () => {
    switch (sector) {
      case "sme": return "bg-sector-sme";
      case "government": return "bg-sector-government";
      case "enterprise": return "bg-sector-enterprise";
      default: return "bg-primary";
    }
  };

  const renderNavItem = (item: any) => {
    const isActive = currentView === item.id;
    
    return (
      <Button
        key={item.id}
        variant={isActive ? "default" : "ghost"}
        className={`w-full justify-start gap-3 h-10 ${
          isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-accent"
        }`}
        onClick={() => onViewChange(item.id)}
      >
        <item.icon className="h-4 w-4 flex-shrink-0" />
        {!collapsed && (
          <>
            <span className="truncate">{item.label}</span>
            {item.badge && (
              <Badge 
                variant="secondary" 
                className={`ml-auto text-xs h-5 ${
                  item.badge === "Active" ? getSectorBadgeColor() + " text-white" :
                  item.badge === "AI" ? "bg-brand-purple text-white" :
                  item.badge === "Beta" ? "bg-warning text-white" :
                  item.badge === "New" ? "bg-info text-white" :
                  item.badge === "Gov" ? "bg-sector-government text-white" :
                  item.badge === "Local" ? "bg-sector-sme text-white" :
                  "bg-muted text-muted-foreground"
                }`}
              >
                {item.badge}
              </Badge>
            )}
          </>
        )}
      </Button>
    );
  };

  return (
    <div className={`${collapsed ? "w-16" : "w-64"} bg-card border-r border-border transition-all duration-300 ${className}`}>
      <div className="p-4">
        {/* Logo */}
        <div className="flex items-center justify-between mb-6">
          {!collapsed && (
            <OmniDashLogo variant="primary" size="md" />
          )}
          {collapsed && (
            <OmniDashLogo variant="icon-only" size="md" />
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed(!collapsed)}
            className="ml-auto"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Sector Badge */}
        {!collapsed && (
          <div className="mb-6">
            <Badge className={`${getSectorBadgeColor()} text-white w-full justify-center capitalize`}>
              {sector} Platform
            </Badge>
          </div>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-6 pb-4">
          {navigationItems.map((group) => (
            <div key={group.group}>
              {!collapsed && (
                <>
                  <h4 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    {group.group}
                  </h4>
                </>
              )}
              <div className="space-y-1">
                {group.items.map(renderNavItem)}
              </div>
              {!collapsed && <Separator className="mt-4" />}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}