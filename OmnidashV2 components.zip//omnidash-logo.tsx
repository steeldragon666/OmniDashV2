import { Bot } from "lucide-react";

interface OmniDashLogoProps {
  variant?: "primary" | "stacked" | "icon-only" | "monochrome";
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function OmniDashLogo({ 
  variant = "primary", 
  size = "md",
  className = ""
}: OmniDashLogoProps) {
  const sizeClasses = {
    sm: "h-6 w-6",
    md: "h-8 w-8", 
    lg: "h-12 w-12"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-xl",
    lg: "text-3xl"
  };

  const LogoIcon = () => (
    <div className={`${sizeClasses[size]} bg-gradient-omnidash rounded-lg flex items-center justify-center flex-shrink-0 hover-glow-orange`}>
      <Bot className={`${size === 'sm' ? 'h-3 w-3' : size === 'md' ? 'h-4 w-4' : 'h-6 w-6'} text-white`} />
    </div>
  );

  if (variant === "icon-only") {
    return (
      <div className={className}>
        <LogoIcon />
      </div>
    );
  }

  if (variant === "stacked") {
    return (
      <div className={`flex flex-col items-center gap-2 ${className}`}>
        <LogoIcon />
        <span className={`${textSizeClasses[size]} font-bold text-gradient-omnidash`}>
          OmniDash
        </span>
      </div>
    );
  }

  if (variant === "monochrome") {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <div className={`${sizeClasses[size]} bg-foreground rounded-lg flex items-center justify-center flex-shrink-0`}>
          <Bot className={`${size === 'sm' ? 'h-3 w-3' : size === 'md' ? 'h-4 w-4' : 'h-6 w-6'} text-background`} />
        </div>
        <span className={`${textSizeClasses[size]} font-bold text-foreground`}>
          OmniDash
        </span>
      </div>
    );
  }

  // Primary variant (default)
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <LogoIcon />
      <span className={`${textSizeClasses[size]} font-bold text-gradient-omnidash`}>
        OmniDash
      </span>
    </div>
  );
}