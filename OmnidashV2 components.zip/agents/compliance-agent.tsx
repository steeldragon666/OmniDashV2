import React, { useState } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";
import { ScrollArea } from "../ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Shield,
  Lock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  Eye,
  Settings,
  Download,
  Upload,
  Search,
  Filter,
  Zap,
  Globe,
  User,
  Database,
  Key,
  Scan,
  Activity,
  Bell,
  Calendar,
  BarChart3,
  TrendingUp,
  Users,
  ExternalLink
} from "lucide-react";

interface SecurityMetric {
  id: string;
  title: string;
  status: "secure" | "warning" | "critical";
  value: string;
  lastChecked: string;
  description?: string;
}

interface ComplianceItem {
  id: string;
  regulation: string;
  status: "compliant" | "partial" | "non-compliant";
  completionRate: number;
  lastAudit: string;
  nextReview: string;
  requirements: {
    total: number;
    completed: number;
    inProgress: number;
    pending: number;
  };
}

interface SecurityAlert {
  id: string;
  type: "vulnerability" | "breach" | "policy" | "access";
  severity: "low" | "medium" | "high" | "critical";
  title: string;
  description: string;
  timestamp: string;
  status: "new" | "investigating" | "resolved";
  affectedSystems?: string[];
}

const mockSecurityMetrics: SecurityMetric[] = [
  {
    id: "1",
    title: "Threat Level",
    status: "secure",
    value: "Low",
    lastChecked: "2 minutes ago",
    description: "No active threats detected"
  },
  {
    id: "2",
    title: "Vulnerability Score",
    status: "warning",
    value: "3.2/10",
    lastChecked: "1 hour ago",
    description: "2 medium-risk vulnerabilities found"
  },
  {
    id: "3",
    title: "Access Control",
    status: "secure",
    value: "98.7%",
    lastChecked: "5 minutes ago",
    description: "All access controls functioning"
  },
  {
    id: "4",
    title: "Data Encryption",
    status: "secure",
    value: "AES-256",
    lastChecked: "30 minutes ago",
    description: "All data encrypted at rest and in transit"
  }
];

const mockComplianceItems: ComplianceItem[] = [
  {
    id: "1",
    regulation: "GDPR",
    status: "compliant",
    completionRate: 96,
    lastAudit: "2024-11-15",
    nextReview: "2025-02-15",
    requirements: {
      total: 25,
      completed: 24,
      inProgress: 1,
      pending: 0
    }
  },
  {
    id: "2",
    regulation: "SOC 2 Type II",
    status: "partial",
    completionRate: 78,
    lastAudit: "2024-10-20",
    nextReview: "2025-01-20",
    requirements: {
      total: 32,
      completed: 25,
      inProgress: 5,
      pending: 2
    }
  },
  {
    id: "3",
    regulation: "ISO 27001",
    status: "compliant",
    completionRate: 92,
    lastAudit: "2024-12-01",
    nextReview: "2025-03-01",
    requirements: {
      total: 45,
      completed: 41,
      inProgress: 3,
      pending: 1
    }
  }
];

const mockSecurityAlerts: SecurityAlert[] = [
  {
    id: "1",
    type: "access",
    severity: "medium",
    title: "Unusual Login Pattern Detected",
    description: "Multiple failed login attempts from IP 192.168.1.100 for user admin@omnidash.com",
    timestamp: "2024-12-10T14:30:00Z",
    status: "investigating",
    affectedSystems: ["Authentication Service", "User Management"]
  },
  {
    id: "2",
    type: "vulnerability",
    severity: "high",
    title: "Outdated Security Certificate",
    description: "SSL certificate for api.omnidash.com expires in 7 days",
    timestamp: "2024-12-10T09:15:00Z",
    status: "new",
    affectedSystems: ["API Gateway"]
  },
  {
    id: "3",
    type: "policy",
    severity: "low",
    title: "Data Retention Policy Violation",
    description: "Old backup files detected beyond retention period",
    timestamp: "2024-12-09T16:45:00Z",
    status: "resolved",
    affectedSystems: ["Backup Service"]
  }
];

export function ComplianceAgent() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedTimeframe, setSelectedTimeframe] = useState("30d");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "secure":
      case "compliant":
      case "resolved": 
        return "bg-success text-white";
      case "warning":
      case "partial":
      case "investigating":
        return "bg-warning text-white";
      case "critical":
      case "non-compliant":
      case "new":
        return "bg-destructive text-white";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "low": return "text-success";
      case "medium": return "text-warning";
      case "high": return "text-destructive";
      case "critical": return "text-destructive font-bold";
      default: return "text-muted-foreground";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "vulnerability": return <AlertTriangle className="h-4 w-4" />;
      case "breach": return <XCircle className="h-4 w-4" />;
      case "policy": return <FileText className="h-4 w-4" />;
      case "access": return <User className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-omnidash text-white glow-orange">
            <Shield className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-brand-navy">Compliance & Security Monitor</h2>
            <p className="text-muted-foreground">Regulatory compliance and security auditing</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-electric-lime text-brand-navy font-semibold">
            <div className="w-2 h-2 rounded-full bg-brand-navy animate-pulse mr-2"></div>
            All Systems Secure
          </Badge>
          <Badge className="bg-brand-navy text-electric-lime border-electric-lime">Last scan: 2 min ago</Badge>
          <Button variant="outline" size="sm" className="border-brand-orange text-brand-orange hover:bg-brand-orange hover:text-white">
            <Scan className="h-4 w-4 mr-2" />
            Run Scan
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="compliance" className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            Compliance
          </TabsTrigger>
          <TabsTrigger value="alerts" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Alerts
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="config" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Configuration
          </TabsTrigger>
        </TabsList>

        {/* Security Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid md:grid-cols-4 gap-4">
            {mockSecurityMetrics.map((metric) => (
              <Card key={metric.id} className="p-4 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-cyan-500/10">
                    <Shield className="h-5 w-5 text-emerald-600" />
                  </div>
                  <Badge className={getStatusColor(metric.status)}>
                    {metric.status}
                  </Badge>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-muted-foreground">{metric.title}</h4>
                  <div className="text-xl font-bold mt-1">{metric.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {metric.description}
                  </div>
                  <div className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {metric.lastChecked}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Vulnerability Scanner */}
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Vulnerability Assessment</h3>
                <div className="flex items-center gap-2">
                  <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7d">7d</SelectItem>
                      <SelectItem value="30d">30d</SelectItem>
                      <SelectItem value="90d">90d</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-4 text-center">
                  <div className="p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-success">0</div>
                    <div className="text-xs text-muted-foreground">Critical</div>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-destructive">0</div>
                    <div className="text-xs text-muted-foreground">High</div>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-warning">2</div>
                    <div className="text-xs text-muted-foreground">Medium</div>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-info">5</div>
                    <div className="text-xs text-muted-foreground">Low</div>
                  </div>
                </div>

                <div className="h-48 flex items-center justify-center bg-gradient-to-br from-emerald-50 to-cyan-50 rounded-lg">
                  <div className="text-center">
                    <Scan className="h-12 w-12 text-emerald-500 mx-auto mb-2" />
                    <p className="text-muted-foreground">Vulnerability scan results</p>
                    <p className="text-sm text-muted-foreground">Timeline showing vulnerability trends and remediation</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Access Control Monitor */}
            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Access Control Status</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Users</span>
                    <div className="text-right">
                      <div className="font-semibold">247</div>
                      <div className="text-xs text-success">+3 today</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Failed Logins (24h)</span>
                    <div className="text-right">
                      <div className="font-semibold">12</div>
                      <div className="text-xs text-warning">+2 vs avg</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Multi-Factor Auth</span>
                    <div className="text-right">
                      <div className="font-semibold">98.7%</div>
                      <div className="text-xs text-success">Enabled</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Privileged Accounts</span>
                    <div className="text-right">
                      <div className="font-semibold">8</div>
                      <div className="text-xs text-info">Monitored</div>
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Data Protection</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Encryption Status</span>
                    <Badge className="bg-success text-white">AES-256</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Backup Health</span>
                    <Badge className="bg-success text-white">100%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Data Classification</span>
                    <Badge className="bg-info text-white">Complete</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Retention Policy</span>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Audit Trail</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span>System health check - 2 min ago</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Activity className="h-4 w-4 text-info" />
                    <span>User permission update - 15 min ago</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-warning" />
                    <span>Access attempt logged - 1 hour ago</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-success" />
                    <span>Data backup completed - 2 hours ago</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Compliance Checker */}
        <TabsContent value="compliance" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Regulatory Compliance Status</h3>
            <Button className="bg-gradient-to-r from-emerald-500 to-cyan-500 text-white">
              <FileText className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
          </div>

          <div className="grid gap-4">
            {mockComplianceItems.map((item) => (
              <Card key={item.id} className="p-6 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-cyan-500/10">
                      <CheckCircle2 className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg">{item.regulation}</h4>
                      <p className="text-sm text-muted-foreground">
                        Last audit: {new Date(item.lastAudit).toLocaleDateString()} • 
                        Next review: {new Date(item.nextReview).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(item.status)}>
                      {item.status}
                    </Badge>
                    <div className="text-right">
                      <div className="font-bold text-lg">{item.completionRate}%</div>
                      <div className="text-xs text-muted-foreground">Complete</div>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <Progress value={item.completionRate} className="h-2" />
                </div>

                <div className="grid grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="font-semibold text-success">{item.requirements.completed}</div>
                    <div className="text-xs text-muted-foreground">Completed</div>
                  </div>
                  <div>
                    <div className="font-semibold text-info">{item.requirements.inProgress}</div>
                    <div className="text-xs text-muted-foreground">In Progress</div>
                  </div>
                  <div>
                    <div className="font-semibold text-warning">{item.requirements.pending}</div>
                    <div className="text-xs text-muted-foreground">Pending</div>
                  </div>
                  <div>
                    <div className="font-semibold">{item.requirements.total}</div>
                    <div className="text-xs text-muted-foreground">Total</div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    {item.requirements.pending > 0 && (
                      <span className="text-warning">⚠ {item.requirements.pending} items need attention</span>
                    )}
                    {item.requirements.pending === 0 && (
                      <span className="text-success">✓ All requirements on track</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* GDPR Specific Dashboard */}
          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">GDPR Data Protection Dashboard</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="space-y-4">
                <h5 className="font-medium">Data Subject Rights</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Access Requests (30d)</span>
                    <Badge variant="outline">12</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Deletion Requests (30d)</span>
                    <Badge variant="outline">3</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Avg Response Time</span>
                    <Badge className="bg-success text-white">18 hours</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>SLA Compliance</span>
                    <Badge className="bg-success text-white">100%</Badge>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h5 className="font-medium">Data Processing</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Lawful Basis Documented</span>
                    <Badge className="bg-success text-white">100%</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Consent Management</span>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Data Minimization</span>
                    <Badge className="bg-success text-white">Compliant</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Purpose Limitation</span>
                    <Badge className="bg-success text-white">Enforced</Badge>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h5 className="font-medium">Security Measures</h5>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Encryption</span>
                    <Badge className="bg-success text-white">AES-256</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Access Controls</span>
                    <Badge className="bg-success text-white">RBAC</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Data Masking</span>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Audit Logging</span>
                    <Badge className="bg-success text-white">Complete</Badge>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Alert System */}
        <TabsContent value="alerts" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Security Alerts</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Select defaultValue="all">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Alerts</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center">
              <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
              <div className="text-2xl font-bold">0</div>
              <div className="text-sm text-muted-foreground">Critical Alerts</div>
            </Card>
            <Card className="p-4 text-center">
              <XCircle className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">2</div>
              <div className="text-sm text-muted-foreground">Active Alerts</div>
            </Card>
            <Card className="p-4 text-center">
              <CheckCircle2 className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">15</div>
              <div className="text-sm text-muted-foreground">Resolved Today</div>
            </Card>
            <Card className="p-4 text-center">
              <Clock className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">4.2h</div>
              <div className="text-sm text-muted-foreground">Avg Resolution</div>
            </Card>
          </div>

          <div className="space-y-4">
            {mockSecurityAlerts.map((alert) => (
              <Card key={alert.id} className="p-4 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start gap-3">
                  <div className={`mt-1 ${getSeverityColor(alert.severity)}`}>
                    {getTypeIcon(alert.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-medium">{alert.title}</h4>
                        <p className="text-sm text-muted-foreground">{alert.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={`text-xs ${getSeverityColor(alert.severity)}`}>
                          {alert.severity}
                        </Badge>
                        <Badge className={getStatusColor(alert.status)}>
                          {alert.status}
                        </Badge>
                      </div>
                    </div>
                    
                    {alert.affectedSystems && (
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-xs text-muted-foreground">Affected systems:</span>
                        {alert.affectedSystems.map((system) => (
                          <Badge key={system} variant="outline" className="text-xs">
                            {system}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(alert.timestamp).toLocaleString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Database className="h-3 w-3" />
                          {alert.type}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-2" />
                          Investigate
                        </Button>
                        {alert.status !== "resolved" && (
                          <Button size="sm" className="bg-gradient-omnidash text-white">
                            <Zap className="h-4 w-4 mr-2" />
                            Resolve
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Reporting Suite */}
        <TabsContent value="reports" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Compliance Reports</h3>
                <Button className="bg-gradient-omnidash text-white">
                  <Download className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </div>

              <div className="space-y-4">
                <Card className="p-4 border-l-4 border-l-success">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Monthly Security Report</h4>
                      <p className="text-sm text-muted-foreground">Comprehensive security posture summary</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-success text-white">Available</Badge>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-info">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">GDPR Compliance Audit</h4>
                      <p className="text-sm text-muted-foreground">Data protection and privacy compliance</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-info text-white">Processing</Badge>
                      <Button variant="outline" size="sm" disabled>
                        <Clock className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-warning">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Vulnerability Assessment</h4>
                      <p className="text-sm text-muted-foreground">Security weaknesses and remediation plans</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-warning text-white">Scheduled</Badge>
                      <Button variant="outline" size="sm">
                        <Calendar className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>

                <Card className="p-4 border-l-4 border-l-purple-500">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">SOC 2 Type II Report</h4>
                      <p className="text-sm text-muted-foreground">Service organization control compliance</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-purple-500 text-white">Draft</Badge>
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Report Schedule</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Weekly Security Brief</span>
                    <Badge variant="outline">Fridays</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Compliance</span>
                    <Badge variant="outline">1st of month</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Quarterly Audit</span>
                    <Badge variant="outline">End of Q</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Annual Review</span>
                    <Badge variant="outline">December</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Executive Summary</h4>
                <div className="space-y-3">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-success">96.2%</div>
                    <div className="text-sm text-muted-foreground">Overall Compliance</div>
                  </div>
                  <Progress value={96} className="h-2" />
                  <div className="text-xs text-muted-foreground">Above industry average (94%)</div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Audit Schedule</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-info" />
                    <span>ISO 27001 - Jan 15, 2025</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-warning" />
                    <span>SOC 2 - Feb 20, 2025</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-success" />
                    <span>GDPR Review - Mar 15, 2025</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Configuration */}
        <TabsContent value="config" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Security Policies</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Password Policy</h5>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Min Length:</span>
                      <span className="font-medium ml-2">12 characters</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Complexity:</span>
                      <span className="font-medium ml-2">High</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Expiration:</span>
                      <span className="font-medium ml-2">90 days</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">History:</span>
                      <span className="font-medium ml-2">24 passwords</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Session Management</h5>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Timeout:</span>
                      <span className="font-medium ml-2">30 minutes</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Max Sessions:</span>
                      <span className="font-medium ml-2">3</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Remember Me:</span>
                      <span className="font-medium ml-2">7 days</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Force Logout:</span>
                      <span className="font-medium ml-2">Enabled</span>
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  <Settings className="h-4 w-4 mr-2" />
                  Modify Policies
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Monitoring Rules</h3>
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h5 className="font-medium text-sm">Failed Login Threshold</h5>
                      <p className="text-xs text-muted-foreground">Alert after 5 failed attempts</p>
                    </div>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h5 className="font-medium text-sm">Unusual Activity Detection</h5>
                      <p className="text-xs text-muted-foreground">Monitor for anomalous patterns</p>
                    </div>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h5 className="font-medium text-sm">Data Access Monitoring</h5>
                      <p className="text-xs text-muted-foreground">Track sensitive data access</p>
                    </div>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h5 className="font-medium text-sm">Privileged Account Watch</h5>
                      <p className="text-xs text-muted-foreground">Monitor admin account usage</p>
                    </div>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  <Zap className="h-4 w-4 mr-2" />
                  Configure Rules
                </Button>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Integration Settings</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <h5 className="font-medium">SIEM Integration</h5>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Splunk</span>
                    <Badge className="bg-success text-white">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">IBM QRadar</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">LogRhythm</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="font-medium">Threat Intelligence</h5>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">VirusTotal</span>
                    <Badge className="bg-success text-white">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">ThreatConnect</span>
                    <Badge className="bg-info text-white">Testing</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">MISP</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="font-medium">Compliance Tools</h5>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">OneTrust</span>
                    <Badge className="bg-success text-white">Connected</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">TrustArc</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Nymity</span>
                    <Badge variant="outline">Available</Badge>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}