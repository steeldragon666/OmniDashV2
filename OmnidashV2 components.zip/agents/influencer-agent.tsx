import React, { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { ScrollArea } from "../ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Separator } from "../ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Users,
  Search,
  MapPin,
  Star,
  TrendingUp,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  CheckCircle2,
  Clock,
  DollarSign,
  Target,
  Filter,
  Mail,
  ExternalLink,
  BarChart3,
  Globe,
  Calendar,
  Zap,
  Award,
  AlertCircle,
  Instagram,
  Twitter,
  Youtube,
  Linkedin,
  Facebook
} from "lucide-react";

interface Influencer {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  platform: string[];
  followers: number;
  engagement: number;
  niche: string[];
  location: string;
  authenticityScore: number;
  recentPosts: number;
  avgLikes: number;
  avgComments: number;
  costPerPost: number;
  availability: "available" | "busy" | "booked";
  verified: boolean;
  collaboration?: {
    status: "active" | "completed" | "negotiating";
    campaign: string;
    startDate: string;
    performance?: {
      reach: number;
      engagement: number;
      conversions: number;
    };
  };
}

const mockInfluencers: Influencer[] = [
  {
    id: "1",
    name: "Sarah Tech",
    handle: "@sarahtech",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612eca6?w=150&h=150&fit=crop&crop=face",
    platform: ["LinkedIn", "Twitter", "YouTube"],
    followers: 125000,
    engagement: 8.7,
    niche: ["Technology", "AI", "Startups"],
    location: "San Francisco, CA",
    authenticityScore: 94,
    recentPosts: 18,
    avgLikes: 2400,
    avgComments: 180,
    costPerPost: 2500,
    availability: "available",
    verified: true,
    collaboration: {
      status: "active",
      campaign: "Q4 AI Innovation Series",
      startDate: "2024-12-01",
      performance: {
        reach: 89000,
        engagement: 7200,
        conversions: 240
      }
    }
  },
  {
    id: "2",
    name: "Marcus Business",
    handle: "@marcusbiz",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    platform: ["LinkedIn", "Instagram"],
    followers: 87000,
    engagement: 6.2,
    niche: ["Business", "Leadership", "Growth"],
    location: "New York, NY",
    authenticityScore: 91,
    recentPosts: 12,
    avgLikes: 1800,
    avgComments: 120,
    costPerPost: 1800,
    availability: "negotiating",
    verified: true
  },
  {
    id: "3",
    name: "Emma Digital",
    handle: "@emmadigital",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    platform: ["Instagram", "TikTok", "YouTube"],
    followers: 340000,
    engagement: 5.8,
    niche: ["Digital Marketing", "Social Media", "Content"],
    location: "Los Angeles, CA",
    authenticityScore: 88,
    recentPosts: 24,
    avgLikes: 8200,
    avgComments: 450,
    costPerPost: 4200,
    availability: "busy",
    verified: false
  }
];

export function InfluencerAgent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedNiche, setSelectedNiche] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [followerRange, setFollowerRange] = useState("");
  const [activeTab, setActiveTab] = useState("discovery");

  const platforms = [
    { id: "linkedin", name: "LinkedIn", icon: Linkedin, color: "text-blue-600" },
    { id: "twitter", name: "Twitter", icon: Twitter, color: "text-sky-500" },
    { id: "instagram", name: "Instagram", icon: Instagram, color: "text-pink-600" },
    { id: "youtube", name: "YouTube", icon: Youtube, color: "text-red-600" },
    { id: "facebook", name: "Facebook", icon: Facebook, color: "text-blue-700" }
  ];

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case "available": return "bg-electric-lime text-brand-navy font-semibold";
      case "busy": return "bg-electric-yellow text-brand-navy font-semibold";
      case "booked": return "bg-hot-pink text-white font-semibold";
      default: return "bg-warm-gray text-brand-navy font-medium";
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-omnidash text-white glow-orange">
            <Users className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-brand-navy">Influencer Intelligence Hub</h2>
            <p className="text-muted-foreground">Discover, analyze, and manage influencer partnerships</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-electric-lime text-brand-navy font-semibold">
            <div className="w-2 h-2 rounded-full bg-brand-navy animate-pulse mr-2"></div>
            Scanning
          </Badge>
          <Badge className="bg-brand-navy text-electric-lime border-electric-lime">1,247 influencers tracked</Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="discovery" className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Discovery
          </TabsTrigger>
          <TabsTrigger value="profiles" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Profiles
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Campaigns
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Discovery Engine */}
        <TabsContent value="discovery" className="space-y-6">
          <div className="grid lg:grid-cols-4 gap-6">
            {/* Search Filters */}
            <Card className="p-6 border-l-4 border-l-electric-lime hover-glow-lime">
              <h3 className="font-semibold text-lg mb-4 text-brand-navy">Discovery Filters</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Search Keywords</label>
                  <Input
                    placeholder="AI, Technology, Startups..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Niche</label>
                  <Select value={selectedNiche} onValueChange={setSelectedNiche}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select niche" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="business">Business</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="lifestyle">Lifestyle</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Followers</label>
                  <Select value={followerRange} onValueChange={setFollowerRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Follower range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10k-50k">10K - 50K</SelectItem>
                      <SelectItem value="50k-100k">50K - 100K</SelectItem>
                      <SelectItem value="100k-500k">100K - 500K</SelectItem>
                      <SelectItem value="500k+">500K+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Location</label>
                  <Input
                    placeholder="City, State, Country"
                    value={selectedLocation}
                    onChange={(e) => setSelectedLocation(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Platforms</label>
                  <div className="grid grid-cols-2 gap-2">
                    {platforms.slice(0, 4).map((platform) => {
                      const Icon = platform.icon;
                      return (
                        <Button
                          key={platform.id}
                          variant="outline"
                          size="sm"
                          className="justify-start"
                        >
                          <Icon className={`h-4 w-4 mr-2 ${platform.color}`} />
                          {platform.name}
                        </Button>
                      );
                    })}
                  </div>
                </div>

                <Button className="w-full bg-gradient-omnidash text-white hover-glow-orange font-semibold">
                  <Search className="h-4 w-4 mr-2" />
                  Search Influencers
                </Button>
              </div>
            </Card>

            {/* Search Results */}
            <div className="lg:col-span-3 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">Discovered Influencers</h3>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Select defaultValue="relevance">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevance</SelectItem>
                      <SelectItem value="followers">Followers</SelectItem>
                      <SelectItem value="engagement">Engagement</SelectItem>
                      <SelectItem value="authenticity">Authenticity</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4">
                {mockInfluencers.map((influencer) => (
                  <Card key={influencer.id} className="p-6 hover:shadow-omnidash-medium transition-all duration-300 border-l-4 border-l-brand-orange hover-glow-orange">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={influencer.avatar} alt={influencer.name} />
                        <AvatarFallback>{influencer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold text-lg">{influencer.name}</h4>
                              {influencer.verified && (
                                <CheckCircle2 className="h-4 w-4 text-blue-500" />
                              )}
                            </div>
                            <p className="text-muted-foreground">{influencer.handle}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">{influencer.location}</span>
                            </div>
                          </div>

                          <div className="text-right">
                            <Badge className={getAvailabilityColor(influencer.availability)}>
                              {influencer.availability}
                            </Badge>
                            <div className="text-sm text-muted-foreground mt-1">
                              ${formatNumber(influencer.costPerPost)}/post
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-6 mt-4">
                          <div className="text-center">
                            <div className="font-semibold">{formatNumber(influencer.followers)}</div>
                            <div className="text-xs text-muted-foreground">Followers</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{influencer.engagement}%</div>
                            <div className="text-xs text-muted-foreground">Engagement</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{influencer.authenticityScore}</div>
                            <div className="text-xs text-muted-foreground">Authenticity</div>
                          </div>
                          <div className="text-center">
                            <div className="font-semibold">{formatNumber(influencer.avgLikes)}</div>
                            <div className="text-xs text-muted-foreground">Avg Likes</div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center gap-2">
                            {influencer.platform.map((platform) => {
                              const platformData = platforms.find(p => p.name === platform);
                              if (!platformData) return null;
                              const Icon = platformData.icon;
                              return (
                                <div key={platform} className="flex items-center gap-1">
                                  <Icon className={`h-4 w-4 ${platformData.color}`} />
                                  <span className="text-xs">{platform}</span>
                                </div>
                              );
                            })}
                          </div>

                          <div className="flex items-center gap-2">
                            {influencer.niche.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                            ))}
                          </div>

                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4 mr-2" />
                              View Profile
                            </Button>
                            <Button size="sm" className="bg-gradient-omnidash text-white hover-glow-orange font-semibold">
                              <Mail className="h-4 w-4 mr-2" />
                              Contact
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Influencer Profiles */}
        <TabsContent value="profiles" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold text-lg mb-4">Detailed Profile Analysis</h3>
              
              {/* Featured Influencer Profile */}
              <div className="space-y-6">
                <div className="flex items-start gap-6">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={mockInfluencers[0].avatar} alt={mockInfluencers[0].name} />
                    <AvatarFallback>{mockInfluencers[0].name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="text-xl font-bold">{mockInfluencers[0].name}</h4>
                      <CheckCircle2 className="h-5 w-5 text-blue-500" />
                      <Badge className="bg-success text-white">Available</Badge>
                    </div>
                    <p className="text-muted-foreground mb-2">{mockInfluencers[0].handle}</p>
                    <p className="text-sm text-muted-foreground mb-4">
                      Tech entrepreneur and AI enthusiast sharing insights on emerging technologies, 
                      startup culture, and digital transformation. Former Google engineer with 8+ years 
                      of experience in machine learning and product development.
                    </p>
                    
                    <div className="grid grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold">{formatNumber(mockInfluencers[0].followers)}</div>
                        <div className="text-xs text-muted-foreground">Followers</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold">{mockInfluencers[0].engagement}%</div>
                        <div className="text-xs text-muted-foreground">Engagement</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold">{mockInfluencers[0].authenticityScore}</div>
                        <div className="text-xs text-muted-foreground">Authenticity</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold">{mockInfluencers[0].recentPosts}</div>
                        <div className="text-xs text-muted-foreground">Posts/Month</div>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Authenticity Score Breakdown */}
                <div>
                  <h5 className="font-medium mb-3">Authenticity Analysis</h5>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Follower Quality</span>
                      <div className="flex items-center gap-2">
                        <Progress value={92} className="w-24 h-2" />
                        <span className="text-sm">92%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Engagement Pattern</span>
                      <div className="flex items-center gap-2">
                        <Progress value={89} className="w-24 h-2" />
                        <span className="text-sm">89%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Content Consistency</span>
                      <div className="flex items-center gap-2">
                        <Progress value={96} className="w-24 h-2" />
                        <span className="text-sm">96%</span>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Audience Demographics */}
                <div>
                  <h5 className="font-medium mb-3">Audience Demographics</h5>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h6 className="text-sm font-medium mb-2">Age Groups</h6>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>25-34</span>
                          <span>42%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>35-44</span>
                          <span>28%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>18-24</span>
                          <span>18%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>45+</span>
                          <span>12%</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h6 className="text-sm font-medium mb-2">Interests</h6>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Technology</span>
                          <span>78%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Business</span>
                          <span>65%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Startups</span>
                          <span>52%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>AI/ML</span>
                          <span>48%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Contact Actions</h4>
                <div className="space-y-2">
                  <Button className="w-full bg-gradient-omnidash text-white">
                    <Mail className="h-4 w-4 mr-2" />
                    Send Proposal
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Calendar className="h-4 w-4 mr-2" />
                    Schedule Call
                  </Button>
                  <Button variant="outline" className="w-full">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Portfolio
                  </Button>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Recent Performance</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Last 30 Days</span>
                    <Badge className="bg-success text-white">+12%</Badge>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold">8.7%</div>
                    <div className="text-xs text-muted-foreground">Avg Engagement</div>
                  </div>
                  <Progress value={87} className="h-2" />
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Collaboration History</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span>Tech Summit 2024</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-info" />
                    <span>Q4 AI Innovation Series</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span>Product Launch Campaign</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Campaign Management */}
        <TabsContent value="campaigns" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-lg">Active Campaigns</h3>
                <Button className="bg-gradient-omnidash text-white">
                  <Target className="h-4 w-4 mr-2" />
                  New Campaign
                </Button>
              </div>

              <div className="space-y-4">
                {mockInfluencers.filter(inf => inf.collaboration).map((influencer) => (
                  <Card key={influencer.id} className="p-4 border-l-4 border-l-primary">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={influencer.avatar} alt={influencer.name} />
                          <AvatarFallback>{influencer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium">{influencer.collaboration?.campaign}</h4>
                          <p className="text-sm text-muted-foreground">{influencer.name} • {influencer.handle}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Calendar className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">
                              Started: {new Date(influencer.collaboration?.startDate || '').toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                      <Badge className={
                        influencer.collaboration?.status === 'active' ? 'bg-success text-white' :
                        influencer.collaboration?.status === 'negotiating' ? 'bg-warning text-white' :
                        'bg-info text-white'
                      }>
                        {influencer.collaboration?.status}
                      </Badge>
                    </div>

                    {influencer.collaboration?.performance && (
                      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                        <div className="text-center">
                          <div className="font-semibold">{formatNumber(influencer.collaboration.performance.reach)}</div>
                          <div className="text-xs text-muted-foreground">Reach</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold">{formatNumber(influencer.collaboration.performance.engagement)}</div>
                          <div className="text-xs text-muted-foreground">Engagement</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold">{influencer.collaboration.performance.conversions}</div>
                          <div className="text-xs text-muted-foreground">Conversions</div>
                        </div>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Campaign Performance</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total Reach</span>
                    <span className="font-semibold">89K</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Engagement Rate</span>
                    <Badge className="bg-success text-white">8.1%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Conversion Rate</span>
                    <Badge className="bg-info text-white">2.7%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">ROI</span>
                    <Badge className="bg-success text-white">340%</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Budget Overview</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total Budget</span>
                    <span className="font-semibold">$15,000</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Spent</span>
                    <span className="font-semibold">$8,500</span>
                  </div>
                  <Progress value={57} className="h-2" />
                  <div className="text-xs text-muted-foreground">57% of budget used</div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Upcoming Milestones</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-warning" />
                    <span>Content review - Dec 15</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-info" />
                    <span>Mid-campaign report - Dec 20</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Award className="h-4 w-4 text-success" />
                    <span>Campaign completion - Dec 31</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center">
              <Users className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">1,247</div>
              <div className="text-sm text-muted-foreground">Influencers Tracked</div>
              <Badge className="mt-2 bg-success text-white">+23</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Target className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">12</div>
              <div className="text-sm text-muted-foreground">Active Campaigns</div>
              <Badge className="mt-2 bg-info text-white">+3</Badge>
            </Card>
            <Card className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">340%</div>
              <div className="text-sm text-muted-foreground">Avg ROI</div>
              <Badge className="mt-2 bg-success text-white">+15%</Badge>
            </Card>
            <Card className="p-4 text-center">
              <DollarSign className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">$124K</div>
              <div className="text-sm text-muted-foreground">Total Spent</div>
              <Badge className="mt-2 bg-warning text-white">This quarter</Badge>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">ROI by Campaign Type</h3>
              <div className="h-64 flex items-center justify-center bg-muted/50 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">ROI visualization would go here</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Platform Performance</h3>
              <div className="space-y-4">
                {platforms.slice(0, 4).map((platform) => {
                  const Icon = platform.icon;
                  const performance = Math.floor(Math.random() * 40) + 60; // Mock data
                  return (
                    <div key={platform.id} className="flex items-center gap-3">
                      <Icon className={`h-5 w-5 ${platform.color}`} />
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-medium">{platform.name}</span>
                          <span className="text-sm">{performance}%</span>
                        </div>
                        <Progress value={performance} className="h-2" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}