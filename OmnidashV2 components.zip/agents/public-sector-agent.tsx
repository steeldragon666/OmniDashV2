import React, { useState } from "react";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Progress } from "../ui/progress";
import { Separator } from "../ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Building,
  Users,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Heart,
  MessageSquare,
  Calendar,
  DollarSign,
  FileText,
  Eye,
  Clock,
  Star,
  ThumbsUp,
  ThumbsDown,
  Award,
  Target,
  Globe,
  Phone,
  Mail,
  MapPin,
  Filter,
  Download,
  Upload,
  Search,
  Bell,
  AlertTriangle,
  CheckCircle2,
  Activity,
  ExternalLink,
  Share2,
  Bookmark,
  Flag
} from "lucide-react";

interface SentimentData {
  platform: string;
  sentiment: number;
  change: number;
  mentions: number;
  trend: "up" | "down" | "stable";
}

interface PolicyMetric {
  id: string;
  title: string;
  status: "active" | "pending" | "draft" | "archived";
  impact: "high" | "medium" | "low";
  reach: number;
  approval: number;
  lastUpdated: string;
  stakeholders: number;
}

interface GrantOpportunity {
  id: string;
  title: string;
  funder: string;
  amount: number;
  eligibility: number;
  deadline: string;
  category: string;
  description: string;
  status: "open" | "closing_soon" | "closed";
}

interface StakeholderGroup {
  id: string;
  name: string;
  type: "citizens" | "business" | "nonprofit" | "other_gov";
  size: number;
  engagement: number;
  satisfaction: number;
  lastContact: string;
}

const mockSentimentData: SentimentData[] = [
  {
    platform: "Twitter",
    sentiment: 73,
    change: 5.2,
    mentions: 1247,
    trend: "up"
  },
  {
    platform: "Facebook",
    sentiment: 68,
    change: -2.1,
    mentions: 892,
    trend: "down"
  },
  {
    platform: "News Media",
    sentiment: 71,
    change: 3.8,
    mentions: 156,
    trend: "up"
  },
  {
    platform: "Public Forums",
    sentiment: 64,
    change: 1.2,
    mentions: 234,
    trend: "stable"
  }
];

const mockPolicies: PolicyMetric[] = [
  {
    id: "1",
    title: "Digital Infrastructure Initiative",
    status: "active",
    impact: "high",
    reach: 125000,
    approval: 78,
    lastUpdated: "2024-12-01",
    stakeholders: 45
  },
  {
    id: "2",
    title: "Green Energy Transition Plan",
    status: "pending",
    impact: "high",
    reach: 89000,
    approval: 65,
    lastUpdated: "2024-11-28",
    stakeholders: 32
  },
  {
    id: "3",
    title: "Public Transportation Expansion",
    status: "draft",
    impact: "medium",
    reach: 67000,
    approval: 72,
    lastUpdated: "2024-12-05",
    stakeholders: 28
  }
];

const mockGrants: GrantOpportunity[] = [
  {
    id: "1",
    title: "Smart City Innovation Grant",
    funder: "Federal Technology Initiative",
    amount: 2500000,
    eligibility: 87,
    deadline: "2025-01-31",
    category: "Technology",
    description: "Funding for innovative smart city technologies that improve citizen services and operational efficiency.",
    status: "open"
  },
  {
    id: "2",
    title: "Community Safety Enhancement Fund",
    funder: "Department of Public Safety",
    amount: 750000,
    eligibility: 92,
    deadline: "2025-01-15",
    category: "Public Safety",
    description: "Grant opportunities for community-based safety programs and infrastructure improvements.",
    status: "closing_soon"
  },
  {
    id: "3",
    title: "Environmental Sustainability Grant",
    funder: "EPA Climate Action Program",
    amount: 1200000,
    eligibility: 78,
    deadline: "2025-02-28",
    category: "Environment",
    description: "Support for local environmental initiatives and climate change adaptation projects.",
    status: "open"
  }
];

const mockStakeholders: StakeholderGroup[] = [
  {
    id: "1",
    name: "Downtown Business Association",
    type: "business",
    size: 247,
    engagement: 82,
    satisfaction: 76,
    lastContact: "2024-12-08"
  },
  {
    id: "2",
    name: "Residents Coalition",
    type: "citizens",
    size: 1840,
    engagement: 67,
    satisfaction: 71,
    lastContact: "2024-12-10"
  },
  {
    id: "3",
    name: "Environmental Action Network",
    type: "nonprofit",
    size: 156,
    engagement: 94,
    satisfaction: 89,
    lastContact: "2024-12-09"
  }
];

export function PublicSectorAgent() {
  const [activeTab, setActiveTab] = useState("sentiment");
  const [selectedTimeframe, setSelectedTimeframe] = useState("30d");

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
      case "open":
        return "bg-success text-white";
      case "pending":
      case "closing_soon":
        return "bg-warning text-white";
      case "draft":
        return "bg-info text-white";
      case "archived":
      case "closed":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "high": return "text-destructive";
      case "medium": return "text-warning";
      case "low": return "text-success";
      default: return "text-muted-foreground";
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-gradient-to-br from-blue-600 via-blue-700 to-purple-700 text-white">
            <Building className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Public Sector Intelligence Tools</h2>
            <p className="text-muted-foreground">Government-specific tools for policy analysis and public engagement</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-sector-government text-white">Government Mode</Badge>
          <Badge variant="outline">Secure Environment</Badge>
          <Button variant="outline" size="sm">
            <FileText className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="sentiment" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            Sentiment
          </TabsTrigger>
          <TabsTrigger value="policy" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Policy Impact
          </TabsTrigger>
          <TabsTrigger value="grants" className="flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            Grant Intelligence
          </TabsTrigger>
          <TabsTrigger value="stakeholders" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Stakeholders
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Performance
          </TabsTrigger>
        </TabsList>

        {/* Public Sentiment Monitor */}
        <TabsContent value="sentiment" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Public Sentiment Analysis</h3>
            <div className="flex items-center gap-2">
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7d">7d</SelectItem>
                  <SelectItem value="30d">30d</SelectItem>
                  <SelectItem value="90d">90d</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Search className="h-4 w-4 mr-2" />
                Search Topics
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            <Card className="p-4 text-center">
              <Heart className="h-8 w-8 text-sector-government mx-auto mb-2" />
              <div className="text-2xl font-bold">72.3%</div>
              <div className="text-sm text-muted-foreground">Overall Approval</div>
              <Badge className="mt-2 bg-success text-white">+5.2%</Badge>
            </Card>
            <Card className="p-4 text-center">
              <MessageSquare className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">2,529</div>
              <div className="text-sm text-muted-foreground">Total Mentions</div>
              <Badge className="mt-2 bg-info text-white">This week</Badge>
            </Card>
            <Card className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">+3.1%</div>
              <div className="text-sm text-muted-foreground">Sentiment Trend</div>
              <Badge className="mt-2 bg-success text-white">Improving</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Users className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">89.4K</div>
              <div className="text-sm text-muted-foreground">Citizens Reached</div>
              <Badge className="mt-2 bg-warning text-white">This month</Badge>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold text-lg mb-4">Platform Sentiment Breakdown</h3>
              <div className="space-y-4">
                {mockSentimentData.map((item, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{item.platform}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-muted-foreground">{formatNumber(item.mentions)} mentions</span>
                          {item.trend === "up" ? 
                            <TrendingUp className="h-4 w-4 text-success" /> :
                            item.trend === "down" ?
                            <TrendingDown className="h-4 w-4 text-destructive" /> :
                            <Activity className="h-4 w-4 text-muted-foreground" />
                          }
                          <span className={`text-sm ${
                            item.change > 0 ? "text-success" : 
                            item.change < 0 ? "text-destructive" : 
                            "text-muted-foreground"
                          }`}>
                            {item.change > 0 ? "+" : ""}{item.change.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={item.sentiment} className="flex-1 h-2" />
                        <span className="text-sm font-medium w-12">{item.sentiment}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Top Discussion Topics</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Infrastructure Projects</span>
                    <Badge className="bg-sector-government text-white">847</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Budget Allocation</span>
                    <Badge className="bg-info text-white">623</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Public Services</span>
                    <Badge className="bg-success text-white">456</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Environmental Policy</span>
                    <Badge className="bg-warning text-white">389</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Community Events</span>
                    <Badge variant="outline">234</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Geographic Sentiment</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Downtown District</span>
                    <span className="font-medium text-success">78%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Residential Areas</span>
                    <span className="font-medium text-success">74%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Industrial Zone</span>
                    <span className="font-medium text-warning">65%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Suburban Communities</span>
                    <span className="font-medium text-success">71%</span>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Crisis Alerts</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-success" />
                    <span>No active crisis detected</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-info" />
                    <span>Monitoring 15 key topics</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bell className="h-4 w-4 text-warning" />
                    <span>3 sentiment dips tracked</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Policy Impact Analyzer */}
        <TabsContent value="policy" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Policy Impact Analysis</h3>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <FileText className="h-4 w-4 mr-2" />
              New Policy Analysis
            </Button>
          </div>

          <div className="grid gap-4">
            {mockPolicies.map((policy) => (
              <Card key={policy.id} className="p-6 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-blue-600/10 to-purple-600/10">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg">{policy.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        Last updated: {new Date(policy.lastUpdated).toLocaleDateString()} • 
                        {policy.stakeholders} stakeholders engaged
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(policy.status)}>
                      {policy.status}
                    </Badge>
                    <Badge variant="outline" className={`text-xs ${getImpactColor(policy.impact)}`}>
                      {policy.impact} impact
                    </Badge>
                  </div>
                </div>

                <div className="grid md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="font-semibold text-lg">{formatNumber(policy.reach)}</div>
                    <div className="text-xs text-muted-foreground">Citizens Reached</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-lg">{policy.approval}%</div>
                    <div className="text-xs text-muted-foreground">Approval Rating</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-lg">{policy.stakeholders}</div>
                    <div className="text-xs text-muted-foreground">Stakeholders</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-lg">
                      {Math.floor(Math.random() * 30) + 10}
                    </div>
                    <div className="text-xs text-muted-foreground">Media Mentions</div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Public Approval</span>
                    <span className="text-sm font-medium">{policy.approval}%</span>
                  </div>
                  <Progress value={policy.approval} className="h-2" />
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    Impact assessment based on {formatNumber(policy.reach)} citizen interactions
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View Analysis
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="h-4 w-4 mr-2" />
                      Share Report
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Policy Effectiveness Trends</h3>
              <div className="h-64 flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg">
                <div className="text-center">
                  <BarChart3 className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                  <p className="text-muted-foreground">Policy effectiveness visualization</p>
                  <p className="text-sm text-muted-foreground">Timeline showing policy impact and public response over time</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Implementation Timeline</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-success"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Digital Infrastructure Initiative</h5>
                    <p className="text-xs text-muted-foreground">Phase 2 implementation - 78% complete</p>
                  </div>
                  <Badge className="bg-success text-white">On Track</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-warning"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Green Energy Transition</h5>
                    <p className="text-xs text-muted-foreground">Awaiting stakeholder feedback</p>
                  </div>
                  <Badge className="bg-warning text-white">Pending</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 border rounded-lg">
                  <div className="w-2 h-2 rounded-full bg-info"></div>
                  <div className="flex-1">
                    <h5 className="font-medium text-sm">Transportation Expansion</h5>
                    <p className="text-xs text-muted-foreground">Environmental impact review</p>
                  </div>
                  <Badge className="bg-info text-white">Review</Badge>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Grant Intelligence System */}
        <TabsContent value="grants" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Grant Opportunity Scanner</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter Grants
              </Button>
              <Button className="bg-gradient-omnidash text-white">
                <Search className="h-4 w-4 mr-2" />
                Find More Grants
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center">
              <DollarSign className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">${formatNumber(4450000)}</div>
              <div className="text-sm text-muted-foreground">Available Funding</div>
            </Card>
            <Card className="p-4 text-center">
              <Target className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">12</div>
              <div className="text-sm text-muted-foreground">Eligible Grants</div>
            </Card>
            <Card className="p-4 text-center">
              <Clock className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">3</div>
              <div className="text-sm text-muted-foreground">Closing Soon</div>
            </Card>
            <Card className="p-4 text-center">
              <CheckCircle2 className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">87%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </Card>
          </div>

          <div className="grid gap-4">
            {mockGrants.map((grant) => (
              <Card key={grant.id} className="p-6 hover:shadow-omnidash-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500/10 to-cyan-500/10">
                      <DollarSign className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-lg">{grant.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {grant.funder} • Deadline: {new Date(grant.deadline).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(grant.status)}>
                      {grant.status.replace("_", " ")}
                    </Badge>
                    <div className="text-right">
                      <div className="font-bold text-lg">{formatCurrency(grant.amount)}</div>
                      <div className="text-xs text-muted-foreground">Available</div>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-4">{grant.description}</p>

                <div className="flex items-center gap-6 mb-4">
                  <div className="text-center">
                    <div className="font-semibold">{grant.eligibility}%</div>
                    <div className="text-xs text-muted-foreground">Eligibility Match</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">{grant.category}</div>
                    <div className="text-xs text-muted-foreground">Category</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">
                      {Math.floor(Math.random() * 50) + 20} days
                    </div>
                    <div className="text-xs text-muted-foreground">Time Remaining</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">
                      {Math.floor(Math.random() * 20) + 5}
                    </div>
                    <div className="text-xs text-muted-foreground">Competitors</div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Eligibility Score</span>
                    <span className="text-sm font-medium">{grant.eligibility}%</span>
                  </div>
                  <Progress value={grant.eligibility} className="h-2" />
                </div>

                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    {grant.status === "closing_soon" ? (
                      <span className="text-warning font-medium">⚠ Application deadline approaching</span>
                    ) : (
                      <span>High probability match based on organizational profile</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    <Button size="sm" className="bg-gradient-omnidash text-white">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Apply Now
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Stakeholder Engagement */}
        <TabsContent value="stakeholders" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Stakeholder Engagement Tracker</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Meeting
              </Button>
              <Button className="bg-gradient-omnidash text-white">
                <Users className="h-4 w-4 mr-2" />
                Add Stakeholder
              </Button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold text-lg mb-4">Stakeholder Groups</h3>
              <div className="space-y-4">
                {mockStakeholders.map((stakeholder) => (
                  <Card key={stakeholder.id} className="p-4 border-l-4 border-l-primary">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-gradient-to-br from-blue-600/10 to-purple-600/10">
                          <Users className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{stakeholder.name}</h4>
                          <p className="text-sm text-muted-foreground capitalize">
                            {stakeholder.type.replace("_", " ")} • {formatNumber(stakeholder.size)} members
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Last contact</div>
                        <div className="text-sm font-medium">
                          {new Date(stakeholder.lastContact).toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-3">
                      <div className="text-center">
                        <div className="font-semibold">{stakeholder.engagement}%</div>
                        <div className="text-xs text-muted-foreground">Engagement</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{stakeholder.satisfaction}%</div>
                        <div className="text-xs text-muted-foreground">Satisfaction</div>
                      </div>
                      <div className="text-center">
                        <div className="font-semibold">{formatNumber(stakeholder.size)}</div>
                        <div className="text-xs text-muted-foreground">Members</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mb-3">
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs">Engagement</span>
                          <span className="text-xs">{stakeholder.engagement}%</span>
                        </div>
                        <Progress value={stakeholder.engagement} className="h-1" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs">Satisfaction</span>
                          <span className="text-xs">{stakeholder.satisfaction}%</span>
                        </div>
                        <Progress value={stakeholder.satisfaction} className="h-1" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="text-xs text-muted-foreground">
                        Next scheduled interaction in 5 days
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Calendar className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>

            <div className="space-y-4">
              <Card className="p-4">
                <h4 className="font-medium mb-3">Engagement Summary</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Active Groups</span>
                    <Badge variant="outline">8</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Total Members</span>
                    <Badge variant="outline">2,243</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Avg Satisfaction</span>
                    <Badge className="bg-success text-white">78.7%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Meetings This Month</span>
                    <Badge variant="outline">12</Badge>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Upcoming Events</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-info" />
                    <span>Town Hall Meeting - Dec 15</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-warning" />
                    <span>Business Roundtable - Dec 18</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-success" />
                    <span>Community Forum - Dec 22</span>
                  </div>
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-medium mb-3">Communication Tracker</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Emails Sent</span>
                    <span className="font-medium">247</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Response Rate</span>
                    <span className="font-medium text-success">82%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Meetings Held</span>
                    <span className="font-medium">34</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Feedback Collected</span>
                    <span className="font-medium">156</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Performance Reporting */}
        <TabsContent value="performance" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-lg">Public Metrics Dashboard</h3>
            <div className="flex items-center gap-2">
              <Select defaultValue="quarterly">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4 text-center">
              <Target className="h-8 w-8 text-sector-government mx-auto mb-2" />
              <div className="text-2xl font-bold">94.2%</div>
              <div className="text-sm text-muted-foreground">Goal Achievement</div>
              <Badge className="mt-2 bg-success text-white">Above Target</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Users className="h-8 w-8 text-info mx-auto mb-2" />
              <div className="text-2xl font-bold">89.4K</div>
              <div className="text-sm text-muted-foreground">Citizens Served</div>
              <Badge className="mt-2 bg-info text-white">This Quarter</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Star className="h-8 w-8 text-warning mx-auto mb-2" />
              <div className="text-2xl font-bold">4.2/5</div>
              <div className="text-sm text-muted-foreground">Service Rating</div>
              <Badge className="mt-2 bg-warning text-white">+0.3</Badge>
            </Card>
            <Card className="p-4 text-center">
              <Clock className="h-8 w-8 text-success mx-auto mb-2" />
              <div className="text-2xl font-bold">92%</div>
              <div className="text-sm text-muted-foreground">On-Time Delivery</div>
              <Badge className="mt-2 bg-success text-white">Excellent</Badge>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Citizen Satisfaction Trends</h3>
              <div className="h-64 flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg">
                <div className="text-center">
                  <Heart className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                  <p className="text-muted-foreground">Satisfaction trend analysis</p>
                  <p className="text-sm text-muted-foreground">Quarterly satisfaction scores and improvement initiatives</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-lg mb-4">Efficiency Indicators</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Service Request Processing</span>
                  <div className="text-right">
                    <div className="font-semibold">2.3 days</div>
                    <div className="text-xs text-success">-0.5 days</div>
                  </div>
                </div>
                <Progress value={85} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Budget Utilization</span>
                  <div className="text-right">
                    <div className="font-semibold">87.3%</div>
                    <div className="text-xs text-info">On track</div>
                  </div>
                </div>
                <Progress value={87} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Digital Services Adoption</span>
                  <div className="text-right">
                    <div className="font-semibold">73.2%</div>
                    <div className="text-xs text-success">+5.1%</div>
                  </div>
                </div>
                <Progress value={73} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Environmental Goals</span>
                  <div className="text-right">
                    <div className="font-semibold">91.8%</div>
                    <div className="text-xs text-success">+2.3%</div>
                  </div>
                </div>
                <Progress value={92} className="h-2" />
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="font-semibold text-lg mb-4">Comparative Analysis</h3>
            <div className="h-64 flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                <p className="text-muted-foreground">Benchmarking visualization</p>
                <p className="text-sm text-muted-foreground">Performance comparison with similar municipalities and best practices</p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}